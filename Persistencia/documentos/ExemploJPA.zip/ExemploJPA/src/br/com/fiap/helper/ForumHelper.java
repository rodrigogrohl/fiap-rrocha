package br.com.fiap.helper;

import javax.persistence.EntityManager;

import br.com.fiap.entity.Forum;

public class ForumHelper {

	private EntityManager em;
	
	public ForumHelper(EntityManager em){
		this.em = em;
	}
	
	public String salvar(Forum forum){
		try {
			em.getTransaction().begin();
			em.persist(forum);
			em.getTransaction().commit();
			return "Forum gravado com sucesso";
		} catch (Exception e) {
			return e.getMessage();
		}
	}
}
