package br.com.fiap.programa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JOptionPane;

import br.com.fiap.entity.Forum;
import br.com.fiap.entity.Usuario;
import br.com.fiap.helper.ForumHelper;

public class TesteForum {
	public static void main(String[] args) {
		
		EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("jpaPU");
		
		EntityManager em = emf.createEntityManager();
		
		Forum forum = new Forum();
		forum.setAssunto("JPA");
		forum.setDescricao("Java Persistence API");		
		
		Usuario u1 = new Usuario();
		u1.setNome("Jose Antonio");
		u1.setEmail("jose@antonio.com.br");
		u1.setForum(forum);
		
		Usuario u2 = new Usuario();
		u2.setNome("Maria Jose");
		u2.setEmail("maria@fiap.com.br");
		u2.setForum(forum);
		
		forum.getUsuarios().add(u1);
		forum.getUsuarios().add(u2);
		
		ForumHelper dao = new ForumHelper(em);
		JOptionPane.showMessageDialog(null, dao.salvar(forum));
		
	}
}
