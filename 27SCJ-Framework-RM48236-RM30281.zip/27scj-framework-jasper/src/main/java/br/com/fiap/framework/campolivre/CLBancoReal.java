 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.utilix.text.Strings;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;
import org.27scj-framework-jasper.vallia.digitoverificador.TipoDeModulo;

 
	
class CLBancoReal extends AbstractCLBancoReal {

	 
	private static final long serialVersionUID = -5294809022535972391L;
	
	private static final Modulo modulo10 = new Modulo(TipoDeModulo.MODULO10);
	
	 
	private static final Integer FIELDS_LENGTH = 4;
	
	 
	CLBancoReal(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 7, Filler.ZERO_LEFT));
		this.add(new Field<String>(calculeDigitoDaPosicao31(titulo.getNumeroDoDocumento(), titulo.getContaBancaria().getAgencia().getCodigo(), titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta()), 1, Filler.ZERO_LEFT));
		this.add(new Field<String>(Strings.eliminateSymbols(titulo.getNumeroDoDocumento()), 13, Filler.ZERO_LEFT));
	}
	
	 	
	private String calculeDigitoDaPosicao31(String nossoNumero,
			Integer agencia, Integer contaCorrente) {

		StringBuilder formula = new StringBuilder();
		String dV = null;

		formula.append(Filler.ZERO_LEFT.fill(nossoNumero, 13));
		formula.append(Filler.ZERO_LEFT.fill(agencia, 4));
		formula.append(Filler.ZERO_LEFT.fill(contaCorrente, 7));

		int restoDivisao = modulo10.calcule(formula.toString());

		int restoSubtracao = (10 - restoDivisao);

		if (restoSubtracao == 10) {
			dV = "0";
		} else {

			dV = "" + restoSubtracao;
		}

		return dV;
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
