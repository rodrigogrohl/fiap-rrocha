 

package br.com.fiap.framework.campolivre;

import static java.lang.String.format;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLCaixaEconomicaFederal extends AbstractCampoLivre {
	
	 
	private static final long serialVersionUID = -4104858478390595830L;
	
	 
	protected AbstractCLCaixaEconomicaFederal(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException{
		
		checkNossoNumero(titulo);
		
		switch(titulo.getNossoNumero().length()){
		case NN10:
			return new CLCaixaEconomicaFederalSICOB(titulo);
		case NN15:
			return new CLCaixaEconomicaFederalSIGCB(titulo);
		case NN17:
			return new CLCaixaEconomicaFederalSINCO(titulo);
		default:
			throw new NotSupportedCampoLivreException(
					format("Campo Livre não suportado para o Nosso Número [%s] de tamanho [%s]." 
					+ " Apenas títulos com Nosso Número de tamanho [%s] são suportados (SICOB, SIGCB e SINCO respectivamente)."
					,titulo.getNossoNumero(), titulo.getNossoNumero().length() 
					,NN10 + "," + NN15 + "," + NN17)
					);
		}
	}
}
