 
package br.com.fiap.framework.campolivre;

import java.util.Arrays;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;
import org.27scj-framework-jasper.vallia.digitoverificador.TipoDeModulo;

 
class CLNossaCaixa extends AbstractCLNossaCaixa {

	 
	private static final long serialVersionUID = -3478291082522788040L;
	
	 
	private static final Integer FIELDS_LENGTH = 8;
	
	 
	private int digito1ASBACE;
	
	protected CLNossaCaixa(Titulo titulo) {

		super(FIELDS_LENGTH);
		
		ContaBancaria contaBancaria = titulo.getContaBancaria();
		Integer modalidadeContaConvertida = convertaModalidadeDaConta(contaBancaria.getModalidade().getCodigoAsInteger());
		
		this.add(new Field<Integer>(getIdentificacaoDoSistemaPeloNossoNumero(titulo.getNossoNumero()), 1));
		
		this.add(new Field<String>(getNossoNumeroCom8Posicoes(titulo.getNossoNumero()), 8));
		
		this.add(new Field<Integer>(contaBancaria.getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(modalidadeContaConvertida, 1));
		
		this.add(new Field<Integer>(contaBancaria.getNumeroDaConta().getCodigoDaConta(), 6, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(contaBancaria.getBanco().getCodigoDeCompensacaoBACEN().getCodigo(), 3));
		
		digito1ASBACE = calculeDigito1ASBACE(titulo, modalidadeContaConvertida);
		int digito2ASBACE = calculeDigito2ASBACE(titulo, modalidadeContaConvertida, digito1ASBACE);
		
		this.add(new Field<Integer>(digito1ASBACE, 1));
		
		this.add(new Field<Integer>(digito2ASBACE, 1));
	}
	
	 
	private int calculeDigito2ASBACE(Titulo titulo, Integer modalidadeDaConta, int digito1) {

		digito1ASBACE = digito1;
		String numeroParaCalculo = gereNumeroParaCalculoDosDigitosASBACE(titulo, modalidadeDaConta) + digito1ASBACE;
		
		Modulo modulo11 = new Modulo(TipoDeModulo.MODULO11);
		modulo11.setLimiteMinimo(2);
		modulo11.setLimiteMaximo(7);
		
		int resto = modulo11.calcule(numeroParaCalculo);
		int digito = resto;
		
		if(resto > 1) {
			digito = modulo11.getMod().valor() - resto;
			
		} else if(resto == 1) {
			
			digito1ASBACE++;
			if(digito1ASBACE == 10) {
				digito1ASBACE = 0;
			}
			
			calculeDigito2ASBACE(titulo, modalidadeDaConta, digito1ASBACE);
		}
		
		return digito;
	}

	 
	private int calculeDigito1ASBACE(Titulo titulo, Integer modalidadeDaConta) {
		
		Modulo modulo10 = new Modulo(TipoDeModulo.MODULO10);
		int resto = modulo10.calcule(gereNumeroParaCalculoDosDigitosASBACE(titulo, modalidadeDaConta));
		
		int digito = resto;
		if(resto > 0) {
			digito = modulo10.getMod().valor() - resto;
		}
		
		return digito;
	}
	
	 
	private String gereNumeroParaCalculoDosDigitosASBACE(Titulo titulo, Integer modalidadeDaConta) {
		
		StringBuilder numeroParaCalculo = new StringBuilder();
		numeroParaCalculo.append(getIdentificacaoDoSistemaPeloNossoNumero(titulo.getNossoNumero()));
		numeroParaCalculo.append(getNossoNumeroCom8Posicoes(titulo.getNossoNumero()));
		numeroParaCalculo.append(Filler.ZERO_LEFT.fill(titulo.getContaBancaria().getAgencia().getCodigo(), 4));
		numeroParaCalculo.append(modalidadeDaConta);
		numeroParaCalculo.append(Filler.ZERO_LEFT.fill(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 6));
		numeroParaCalculo.append(titulo.getContaBancaria().getBanco().getCodigoDeCompensacaoBACEN().getCodigo());
		
		return numeroParaCalculo.toString();
	}

	 
	private Integer getIdentificacaoDoSistemaPeloNossoNumero(String nossoNumero) {
		
		return new Integer(nossoNumero.substring(0,1));
	}
	
	 
	private String getNossoNumeroCom8Posicoes(String nossoNumero) {
		
		if (  (nossoNumero.length() != 9) || (!nossoNumero.substring(0, 2).equals("99"))  ) 
			throw new CampoLivreException("O nosso número deve conter exatamente 9 posições, sendo as 2 posições iniciais obrigatoriamente igual a 99.");
		
		return nossoNumero.substring(1);
	}

	 
	private Integer convertaModalidadeDaConta(Integer modalidadeDaConta) {
	
		final int[] modalidadesValidas = {1, 4, 9, 13, 16, 17, 18};
		
		if (modalidadeDaConta == null || Arrays.binarySearch(modalidadesValidas, modalidadeDaConta.intValue()) < 0) {
			throw new CampoLivreException("Campo livre diponível somente para títulos de contas correntes com modalidades 01, 04, 09, 13, 16, 17 e 18.");
		}
		
		int modalidadeConvertida = modalidadeDaConta.intValue();
		
		if (modalidadeDaConta.intValue() > 9) {
			modalidadeConvertida = modalidadeDaConta.intValue() - 10;
		}
	
		return modalidadeConvertida;
	}

	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
