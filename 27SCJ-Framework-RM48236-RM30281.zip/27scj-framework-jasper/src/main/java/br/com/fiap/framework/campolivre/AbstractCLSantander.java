package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLSantander extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = 1882819688182515282L;

	 
	protected AbstractCLSantander(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) {
		
		return new CLBancoSantander(titulo);
	}
}
