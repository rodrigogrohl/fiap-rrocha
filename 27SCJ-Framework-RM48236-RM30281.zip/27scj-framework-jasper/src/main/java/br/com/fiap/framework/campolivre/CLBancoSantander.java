package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBancoSantander extends AbstractCLSantander implements CampoLivre {

	 
	private static final long serialVersionUID = -412221524249334574L;

	 
	private static final Integer FIELDS_LENGTH = 5;

	 
	private static final Integer CONSTANTE = Integer.valueOf(9);

	 
	private static final String IOF_SEGURADORA = "IOF_SEGURADORA";

	 
	private static final int CARTEIRA_RAPIDA_COM_REGISTRO = 101;

	 
	private static final int CARTEIRA_RAPIDA_SEM_REGISTRO = 201;

	 
	private static final int CARTEIRA_SIMPLES_SEM_REGISTRO = 102;

	CLBancoSantander(Titulo titulo) {
		super(FIELDS_LENGTH);

		ContaBancaria conta = titulo.getContaBancaria();
		StringBuilder nossoNumero = new StringBuilder(titulo.getNossoNumero());
		nossoNumero.append(titulo.getDigitoDoNossoNumero());

		this.add(new Field<Integer>(CONSTANTE, 1));
		this.add(new Field<Integer>(conta.getNumeroDaConta().getCodigoDaConta(), 7, Filler.ZERO_LEFT));
		
		this.add(new Field<String>(nossoNumero.toString(), 13, Filler.ZERO_LEFT));

		// IOF – Seguradoras

		if (Objects.isNotNull(titulo.getParametrosBancarios())
				&& Objects.isNotNull(titulo.getParametrosBancarios().getValor(
						IOF_SEGURADORA))) {

			this.add(new Field<Integer>((Integer) titulo
					.getParametrosBancarios().getValor(IOF_SEGURADORA), 1));

		} else {

			this.add(new Field<Integer>(0, 1));
		}

		// Tipo de Modalidade Carteira

		switch (conta.getCarteira().getCodigo()) {

		case CARTEIRA_RAPIDA_COM_REGISTRO:
		case CARTEIRA_RAPIDA_SEM_REGISTRO:
		case CARTEIRA_SIMPLES_SEM_REGISTRO:

			this.add(new Field<Integer>(conta.getCarteira().getCodigo(), 3,
					Filler.ZERO_LEFT));

			break;

		default:
			
			throw new IllegalArgumentException(String.format(
					"CARTEIRA [%s] NÃO SUPORTADA!", conta.getCarteira()
							.getCodigo()));
		}
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
