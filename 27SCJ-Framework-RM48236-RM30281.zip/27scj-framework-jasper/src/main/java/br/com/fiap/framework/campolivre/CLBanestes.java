 
package br.com.fiap.framework.campolivre;

import static org.27scj-framework-jasper.utilix.Objects.exists;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.TipoDeCobranca;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;
import org.27scj-framework-jasper.vallia.digitoverificador.TipoDeModulo;

 
class CLBanestes extends AbstractCLBanestes {
	
	 
	private static final long serialVersionUID = 476678476727564241L;
	
	private static final Integer FIELDS_LENGTH = 5;

	public CLBanestes(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		this.add(new Field<Integer>(Integer.valueOf(titulo.getNossoNumero()), 8, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 11, Filler.ZERO_LEFT));
		
		final Integer codigoDaCarteiraDeCobranca = titulo.getContaBancaria().getCarteira().getCodigo();
		
		if (exists(codigoDaCarteiraDeCobranca)) {
			this.add(new Field<Integer>(codigoDaCarteiraDeCobranca, 1));
			
		} else {
			
			final TipoDeCobranca tipoDeCobranca = titulo.getContaBancaria().getCarteira().getTipoCobranca();
			
			switch (tipoDeCobranca) {
			
				case SEM_REGISTRO:
					this.add(new Field<Integer>(2, 1));
					break;
					
				case COM_REGISTRO:
					if (codigoDaCarteiraDeCobranca >= 3 && codigoDaCarteiraDeCobranca <= 7) {
						
						this.add(new Field<Integer>(codigoDaCarteiraDeCobranca, 1));
						break;
						
					} else {
						throw new CampoLivreException("Código da carteira de cobrança com registro deve ser" +
							" especificado com 3,4,5,6 ou 7. Valor atual = [" + codigoDaCarteiraDeCobranca + "]");
					}
					
				default:
					
					if (tipoDeCobranca == null) {
						throw new CampoLivreException("Tipo de cobrança da carteira não foi especificado!");
					} else {
						throw new CampoLivreException("Tipo de cobrança [" + tipoDeCobranca  + "] não é suportado!");
					}
			}
		}
		
		this.add(new Field<Byte>(titulo.getContaBancaria().getBanco().getCodigoDeCompensacaoBACEN().getCodigo().byteValue(), 3, Filler.ZERO_LEFT));
		
		this.setFieldsLength(this.size());
		this.setStringLength(STRING_LENGTH - 2);
		
		this.add(new Field<Byte>(calculaDuploDV(this.write()), 2, Filler.ZERO_LEFT));
		
		this.setFieldsLength(this.size());
		this.setStringLength(STRING_LENGTH);
	}
	
	 
	private byte calculaDuploDV(String numero) {
		final byte duploDV;
		
		byte primeiroDV = calculaPrimeiroDV();
		
		final byte segundoDV;
		
		// resto proveniente do módulo 11 com pesos de 2 a 7
		int restoDoModulo11 = new Modulo(TipoDeModulo.MODULO11, 7, 2).calcule(numero + primeiroDV);
		
		if (restoDoModulo11 == 0) {
			segundoDV = 0;
		} else	if (restoDoModulo11 == 1) {
			if (primeiroDV == 9) {
				primeiroDV = 0;
			} else {
				primeiroDV++;
			}
			segundoDV = (byte) new Modulo(TipoDeModulo.MODULO11, 7, 2).calcule(numero + primeiroDV);
		} else {
			segundoDV = (byte) (11 - restoDoModulo11);
		}
		
		duploDV = Byte.parseByte(String.valueOf(primeiroDV) + String.valueOf(segundoDV)); 
		
		return duploDV;
	}

	 
	private byte calculaPrimeiroDV() {
		final byte primeiroDV;
		
		// resto proveniente do módulo 10
		byte restoDoModulo10 = (byte) new Modulo(TipoDeModulo.MODULO10).calcule(this.write());
		
		// se não houver resto, primeiroDV = 0
		// caso contrário, primeiroDV = 10 - resto
		primeiroDV = (byte) ((restoDoModulo10 == 0) ? 0 : 10 - restoDoModulo10);
		return primeiroDV;
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

}
