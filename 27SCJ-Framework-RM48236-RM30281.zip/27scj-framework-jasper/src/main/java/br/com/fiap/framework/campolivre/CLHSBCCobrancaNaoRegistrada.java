 

package br.com.fiap.framework.campolivre;

import java.util.Calendar;
import java.util.Date;

import org.27scj-framework-jasper.domkee.financeiro.banco.ParametrosBancariosMap;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.domkee.financeiro.banco.hsbc.TipoIdentificadorCNR;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLHSBCCobrancaNaoRegistrada extends AbstractCLHSBC {

	 
	private static final long serialVersionUID = -1253549781074159862L;

	 
	private static final Integer FIELDS_LENGTH = 4;

	 
	CLHSBCCobrancaNaoRegistrada(Titulo titulo) {

		super(FIELDS_LENGTH);

		checkExistsParametrosBancarios(titulo);
		checkExistsParametroTipoIdentificadorCNR(titulo
				.getParametrosBancarios());

		TipoIdentificadorCNR tipoIdentificadorCNR = titulo
				.getParametrosBancarios().getValor(
						TipoIdentificadorCNR.class.getName());

		ContaBancaria conta = titulo.getContaBancaria();
		String nossoNumero = titulo.getNossoNumero();

		// Conta do cedente (sem dígito)
		this.add(new Field<Integer>(
				conta.getNumeroDaConta().getCodigoDaConta(), 7,
				Filler.ZERO_LEFT));

		// Nosso número (sem dígito)
		this.add(new Field<String>(nossoNumero, 13, Filler.ZERO_LEFT));

		this.add(new Field<String>(getDataVencimentoFormatoJuliano(
				tipoIdentificadorCNR, titulo.getDataDoVencimento()), 4,
				Filler.ZERO_LEFT));

		// 2 FIXO (Código do Aplicativo CNR - Cob. Não Registrada)
		this.add(new Field<Integer>(2, 1));

	}

	private String getDataVencimentoFormatoJuliano(TipoIdentificadorCNR tipoIdentificadorCNR, Date vencimento) {

		switch (tipoIdentificadorCNR) {

		case SEM_VENCIMENTO:

			return "0000";

		case COM_VENCIMENTO:

			return getVencimentoFormatoJuliano(vencimento);

		default:
			throw new IllegalStateException(
					"Tipo de identificador CNR desconhecido!");
		}
	}

	private String getVencimentoFormatoJuliano(Date vencimento) {

		Calendar c = Calendar.getInstance();
		c.setTime(vencimento);

		return new StringBuilder(String.valueOf(c.get(Calendar.DAY_OF_YEAR)))
				.append(String.valueOf(c.get(Calendar.YEAR) % 10))
				.toString();
	}

	private void checkExistsParametrosBancarios(Titulo titulo) {

		if (Objects.isNull(titulo.getParametrosBancarios())
				&& titulo.getParametrosBancarios().isVazio()) {

			throw new CampoLivreException(
					"Parâmetros bancários nulos em \"Titulo.parametrosBancarios\". O parâmetro bancário de nome e tipo [ "
							+ TipoIdentificadorCNR.class.getName()
							+ " ] deve ser fornecido para este caso.");

		}
	}

	private void checkExistsParametroTipoIdentificadorCNR(ParametrosBancariosMap parametros) {

		TipoIdentificadorCNR tipoIdentificadorCNR = parametros
				.getValor(TipoIdentificadorCNR.class.getName());

		if (Objects.isNull(tipoIdentificadorCNR)) {

			throw new CampoLivreException(
					"Parâmetro bancário ["
							+ TipoIdentificadorCNR.class.getName()
							+ " ] não encontrado em \"Titulo.parametrosBancarios\". O nome do parâmetro deve ser o \"qualify name\" da classe.");
		}
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
