 


package br.com.fiap.framework;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.AbstractLineOfFields;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.vallia.digitoverificador.BoletoCodigoDeBarrasDV;

import br.com.fiap.framework.campolivre.CampoLivre;


 
public final class CodigoDeBarras extends AbstractLineOfFields{

	 
	private static final long serialVersionUID = 748913164143978133L;
	
	private static Logger log = Logger.getLogger(CodigoDeBarras.class);
	
	 
	private static final Integer FIELDS_LENGTH = 6;
	
	 
	private static final Integer STRING_LENGTH = 44;

	 
	public static final Date DATA_BASE_DO_FATOR_DE_VENCIMENTO = new GregorianCalendar(
			1997, Calendar.OCTOBER, 7).getTime();

	
	 
	private Field<String> codigoDoBanco;
	
	 
	private Field<Integer> codigoDaMoeda;
	
	 
	private Field<Integer> digitoVerificadorGeral;
	
	 
	private Field<Integer> fatorDeVencimento;
	
	 
	private Field<BigDecimal> valorNominalDoTitulo;
	
	 
	private Field<String> campoLivre;
	
	 
	CodigoDeBarras(Titulo titulo, CampoLivre campoLivre) {
		super(FIELDS_LENGTH ,STRING_LENGTH);
		
		if(log.isTraceEnabled())
			log.trace("Instanciando o CodigoDeBarras");
			
		if(log.isDebugEnabled()){
			log.debug("titulo instance : "+titulo);
			log.debug("campoLivre instance : "+campoLivre);
		}

		codigoDoBanco = new Field<String>("0", 3, Filler.ZERO_LEFT );
		codigoDaMoeda = new Field<Integer>(0, 1, Filler.ZERO_LEFT);
		digitoVerificadorGeral = new Field<Integer>(0, 1, Filler.ZERO_LEFT);
		fatorDeVencimento = new Field<Integer>(0, 4, Filler.ZERO_LEFT);
		valorNominalDoTitulo = new Field<BigDecimal>(new BigDecimal(0), 10, Filler.ZERO_LEFT);
		this.campoLivre = new Field<String>(StringUtils.EMPTY, 25);
		
		add(codigoDoBanco);
		add(codigoDaMoeda);
		add(digitoVerificadorGeral);
		add(fatorDeVencimento);
		add(valorNominalDoTitulo);
		add(this.campoLivre);
	
		ContaBancaria contaBancaria = titulo.getContaBancaria();
		this.codigoDoBanco.setValue(contaBancaria.getBanco().getCodigoDeCompensacaoBACEN().getCodigoFormatado());
		
		this.codigoDaMoeda.setValue(titulo.getTipoDeMoeda().getCodigo());
		
		//Was here DigitoVerificador 
		//But wait
		this.calculateAndSetFatorDeVencimento(titulo.getDataDoVencimento());
		
		this.valorNominalDoTitulo.setValue(titulo.getValor().movePointRight(2));
		this.campoLivre.setValue(campoLivre.write());
		
		//Now you can
		this.calculateAndSetDigitoVerificadorGeral();
		
		if(log.isDebugEnabled() || log.isTraceEnabled())
			log.debug("codigoDeBarra instanciado : "+this);
	}

	
	
	private void calculateAndSetDigitoVerificadorGeral() {
		
		if (log.isTraceEnabled())
			log.trace("Calculando Digito Verificador Geral");

		// Instanciando o objeto irá calcular o dígito verificador do boleto.
		BoletoCodigoDeBarrasDV calculadorDV = new BoletoCodigoDeBarrasDV();

		// Preparando o conjunto de informações que será a base para o cálculo
		// do dígito verificador, conforme normas da FEBRABAN.
		StringBuilder toCalculateDV = new StringBuilder(codigoDoBanco.write())
		.append(codigoDaMoeda.write())
		.append(fatorDeVencimento.write())
		.append(valorNominalDoTitulo.write())
		.append(campoLivre.write());

		// Realizando o cálculo dígito verificador e em seguida armazenando 
		// a informação no campo "digitoVerificadorGeral".
		digitoVerificadorGeral.setValue(
				calculadorDV.calcule(toCalculateDV.toString())
				);

		if (log.isDebugEnabled())
			log.debug("Digito Verificador Geral calculado : "
					+ digitoVerificadorGeral.getValue());
	}

	 
	private void calculateAndSetFatorDeVencimento(Date vencimento) {

		fatorDeVencimento.setValue(
				FatorDeVencimento.toFator(vencimento));
	}

	 
	Field<String> getCodigoDoBanco() {
		return codigoDoBanco;
	}

	 
	void setCodigoDoBanco(Field<String> codigoDoBanco) {
		this.codigoDoBanco = codigoDoBanco;
	}

	 
	Field<Integer> getCodigoDaMoeda() {
		return codigoDaMoeda;
	}

	 
	void setCodigoDaMoeda(Field<Integer> codigoDaMoeda) {
		this.codigoDaMoeda = codigoDaMoeda;
	}

	 
	Field<Integer> getDigitoVerificadorGeral() {
		return digitoVerificadorGeral;
	}

	 
	void setDigitoVerificadorGeral(Field<Integer> digitoVerificadorGeral) {
		this.digitoVerificadorGeral = digitoVerificadorGeral;
	}

	 
	Field<Integer> getFatorDeVencimento() {
		return fatorDeVencimento;
	}

	 
	void setFatorDeVencimento(Field<Integer> fatorDeVencimento) {
		this.fatorDeVencimento = fatorDeVencimento;
	}

	 
	Field<BigDecimal> getValorNominalDoTitulo() {
		return valorNominalDoTitulo;
	}

	 
	void setValorNominalDoTitulo(Field<BigDecimal> valorNominalDoTitulo) {
		this.valorNominalDoTitulo = valorNominalDoTitulo;
	}

	 
	Field<String> getCampoLivre() {
		return campoLivre;
	}

	 
	void setCampoLivre(Field<String> campoLivre) {
		this.campoLivre = campoLivre;
	}

	@Override
	public String toString() {
		return Objects.toString(this);
	}
}
