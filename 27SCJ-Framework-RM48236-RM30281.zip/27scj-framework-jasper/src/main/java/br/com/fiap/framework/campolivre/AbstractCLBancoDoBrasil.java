 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBancoDoBrasil extends AbstractCampoLivre {
	
	 
	private static final long serialVersionUID = -7324315662526104153L;

	 
	protected AbstractCLBancoDoBrasil(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException{

		checkNossoNumero(titulo);
		
		switch(titulo.getNossoNumero().length()){
		case NN10:
			return new CLBancoDoBrasilNN10(titulo);
		case NN11:
			return new CLBancoDoBrasilNN11(titulo);
		case NN17:
			return new CLBancoDoBrasilNN17(titulo);
		default:
			throw new NotSupportedCampoLivreException(
					"Campo livre diponível somente para títulos com nosso número " +
					"composto por 10 posições(convênio com 7), 11 posições ou " +
					"17 posições(convênio com 6)."
				);
		}
	}
}
