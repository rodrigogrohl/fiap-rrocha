package br.com.fiap.framework.campolivre;

import java.math.BigDecimal;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBancoRuralCobrancaNaoRegistradaSeguradora extends AbstractCLBancoRural{

	 
	private static final long serialVersionUID = -2427800425370567806L;

	 
	private static final Integer FIELDS_LENGTH = Integer.valueOf(6);
	
	 
	private static final Integer TIPO_COBRANCA = Integer.valueOf(4);
	
	 
	CLBancoRuralCobrancaNaoRegistradaSeguradora(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		this.add( new Field<Integer>( TIPO_COBRANCA , 1 ) );
		this.add( new Field<Integer>( titulo.getContaBancaria().getAgencia().getCodigo(), 3 , Filler.ZERO_LEFT ) );
		this.add( new Field<Integer>((Integer)titulo.getParametrosBancarios().getValor(CODIGO_REDUZIDO), 3, Filler.ZERO_LEFT ) );
		this.add( new Field<String>( titulo.getNossoNumero(), 10 , Filler.ZERO_LEFT ) );
		this.add( new Field<String>( titulo.getDigitoDoNossoNumero(), 1 , Filler.ZERO_LEFT ) );
		this.add( new Field<BigDecimal>((BigDecimal)titulo.getParametrosBancarios().getValor("VALOR_IOS"), 7, Filler.ZERO_LEFT));
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
