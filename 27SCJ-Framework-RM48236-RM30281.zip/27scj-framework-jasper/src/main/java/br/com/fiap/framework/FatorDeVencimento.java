 

package br.com.fiap.framework;

import static java.lang.String.format;
import static org.27scj-framework-jasper.utilix.Objects.isNull;
import static org.27scj-framework-jasper.utilix.text.DateFormat.DDMMYYYY_B;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.time.DateUtils;
import org.27scj-framework-jasper.utilix.Dates;

 
public class FatorDeVencimento{

	 
	private static final long serialVersionUID = -9041865935492749542L;

	 
	private static final Calendar BASE_DO_FATOR_DE_VENCIMENTO = new GregorianCalendar(1997, Calendar.OCTOBER, 7);
	
	 
	private static final Date DATA_BASE_DO_FATOR_DE_VENCIMENTO = BASE_DO_FATOR_DE_VENCIMENTO.getTime();

	 
	private static final Date DATA_LIMITE_DO_FATOR_DE_VENCIMENTO = new GregorianCalendar(2025, Calendar.FEBRUARY, 21).getTime();

	 
	public static int toFator(Date data) throws IllegalArgumentException {

		if (isNull(data)) {
			
			throw new IllegalArgumentException("Impossível realizar o cálculo do fator de vencimento de uma data nula!");
			
		} else {
			
			Date dataTruncada = DateUtils.truncate(data, Calendar.DATE);
			
			checkIntervalo(dataTruncada);
				
			return (int) Dates.calculeDiferencaEmDias(DATA_BASE_DO_FATOR_DE_VENCIMENTO, dataTruncada);
		}
	}
	
	 
	public static Date toDate(int fator) throws IllegalArgumentException {
		
		checkIntervalo(fator);
		
		Calendar date = (Calendar) BASE_DO_FATOR_DE_VENCIMENTO.clone();
		
		date.add(Calendar.DAY_OF_YEAR, fator);
		
		return  DateUtils.truncate(date.getTime(), Calendar.DATE);
	}

	 
	private static void checkIntervalo(Date dataVencimentoTruncada) throws IllegalArgumentException {
		
		if(dataVencimentoTruncada.before(DATA_BASE_DO_FATOR_DE_VENCIMENTO)
				|| dataVencimentoTruncada.after(DATA_LIMITE_DO_FATOR_DE_VENCIMENTO)) {
			
			throw new IllegalArgumentException(
					format("Para o cálculo do fator de vencimento se faz necessário informar uma data entre %s e %s.",
					DDMMYYYY_B.format(DATA_BASE_DO_FATOR_DE_VENCIMENTO), DDMMYYYY_B.format(DATA_LIMITE_DO_FATOR_DE_VENCIMENTO)));
					
		}
	}
	
	 
	private static void checkIntervalo(int fatorDeVencimento) throws IllegalArgumentException {

		if (fatorDeVencimento < 0 || fatorDeVencimento > 9999) {

			throw new IllegalArgumentException(
					"Impossível transformar em data um fator menor que zero! O fator de vencimento deve ser um número entre 0 e 9999.");
		}
	}
}
