package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBancoRuralCobrancaRegistrada extends AbstractCLBancoRural{
	
	private static final long serialVersionUID = -5166628254198207874L;
	
	 
	private static final Integer FIELDS_LENGTH = Integer.valueOf(7);
	
	 
	private static final Integer TIPO_COBRANCA = Integer.valueOf(0);
	
	 
	private static final String ZEROS = "000";

	 
	CLBancoRuralCobrancaRegistrada(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		this.add( new Field<Integer>( TIPO_COBRANCA , 1 ) );
		this.add( new Field<Integer>( titulo.getContaBancaria().getAgencia().getCodigo(), 3 , Filler.ZERO_LEFT ) );
		this.add( new Field<Integer>( titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 9, Filler.ZERO_LEFT ) );
		this.add( new Field<String>( titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta(), 1 ) );
		this.add( new Field<String>( titulo.getNossoNumero(), 7 , Filler.ZERO_LEFT ) );
		this.add( new Field<String>( titulo.getDigitoDoNossoNumero(), 1 ) );
		this.add( new Field<String>( ZEROS, 3));
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
