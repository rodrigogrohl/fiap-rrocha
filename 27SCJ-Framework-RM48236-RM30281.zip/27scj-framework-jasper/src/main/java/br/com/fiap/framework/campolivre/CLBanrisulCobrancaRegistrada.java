 
package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBanrisulCobrancaRegistrada extends AbstractCLBanrisul {

	 
	private static final long serialVersionUID = 1577477244182494602L;
	
	private static final Integer FIELDS_LENGTH = 7;

	CLBanrisulCobrancaRegistrada(Titulo titulo) {
		super(FIELDS_LENGTH);

		this.add(new Field<Integer>(1, 1));
		this.add(new Field<String>("1", 1));
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 7, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(Integer.valueOf(titulo.getNossoNumero()),8, Filler.ZERO_LEFT));
		this.add(new Field<String>("40", 2));
		this.add(new Field<String>(calculaDuploDigito(concateneOsCamposExistentesAteOMomento()),2));
	}

	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
