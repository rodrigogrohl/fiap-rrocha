 

package br.com.fiap.framework.pdf;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.Strings;

 
public class Files {

	 
	public static File bytesToFile(String pathName, byte[] bytes) throws FileNotFoundException, IOException {

		Strings.checkNotBlank(pathName);
		Objects.checkNotNull(bytes);

		return bytesToFile(new File(pathName), bytes);
	}
	
	 
	public static File bytesToFile(File file, byte[] bytes) throws FileNotFoundException, IOException {

		Objects.checkNotNull(file);
		Objects.checkNotNull(bytes);

		if(file.length() > Integer.MAX_VALUE){
			throw new IllegalArgumentException("TAMANHO DO ARQUIVO MAIOR DO QUE O SUPORTADO: "+Integer.MAX_VALUE);
		}
		
		OutputStream out = new FileOutputStream(file);

		out.write(bytes);
		out.flush();
		out.close();

		return file;
	}

	 
	public static ByteArrayOutputStream bytesToStream(byte[] bytes) throws IOException {

		Objects.checkNotNull(bytes);

		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
		byteOut.write(bytes);

		return byteOut;
	}
}
