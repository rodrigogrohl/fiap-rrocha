
 
	
package br.com.fiap.framework;

 

public class BoletoException extends RuntimeException {

	 
	private static final long serialVersionUID = -3874521668322644183L;

	 
	public BoletoException() {
		
	}

	 
	public BoletoException(String message, Throwable cause) {
		super(message, cause);
		
	}

	 
	public BoletoException(String message) {
		super(message);
		
	}

	 
	public BoletoException(Throwable cause) {
		super(cause);
		
	}

}
