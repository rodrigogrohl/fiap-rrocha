 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBancoIntermedium extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -8103863452995430046L;

	 
	protected AbstractCLBancoIntermedium(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo){
		
		return new CLBancoIntermedium(titulo);
	}
}
