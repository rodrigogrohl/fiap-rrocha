 

package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBancoReal extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -2020155324741631945L;

	 
	protected AbstractCLBancoReal(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo){
		
		return new CLBancoReal(titulo);
	}
}
