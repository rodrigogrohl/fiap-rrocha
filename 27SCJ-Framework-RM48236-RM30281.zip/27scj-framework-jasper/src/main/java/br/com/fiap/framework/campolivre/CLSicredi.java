 

package br.com.fiap.framework.campolivre;

import static java.lang.String.format;
import static java.math.BigDecimal.ZERO;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;
import org.27scj-framework-jasper.vallia.digitoverificador.TipoDeModulo;

 
class CLfiapi extends AbstractCLfiapi {

	 
	private static final long serialVersionUID = 7697120719706717353L;
	
	 
	protected static final Integer FIELDS_LENGTH = 9;

	 
	private static final String COBRANCA_COM_REGISTRO = "1";
	
	 
	private static final String COBRANCA_SEM_REGISTRO = "3";

	 
	private static final Integer CARTEIRA_SIMPLES_VALUE = Integer.valueOf(1);
	
	 
	private static final String POSTO_DA_AGENCIA = "PostoDaAgencia";
	
	 
	private static final Field<Integer> FIELD_CARTEIRA = new Field<Integer>(CARTEIRA_SIMPLES_VALUE, 1);
	
	 
	private static final Modulo modulo11 = new Modulo(TipoDeModulo.MODULO11);

	 
	protected CLfiapi() {
		
		super(FIELDS_LENGTH);
	}
	
	@Override
	protected void checkValues(Titulo titulo){
		
		checkCarteiraNotNull(titulo);
		checkCodigoDaCarteira(titulo);
		checkCarteiraSimples(titulo);
		checkRegistroDaCarteiraNotNull(titulo);
		checkNossoNumero(titulo);
		checkTamanhoDoNossoNumero(titulo, NN8);
		checkDigitoDoNossoNumero(titulo);
		checkTamanhoDigitoDoNossoNumero(titulo, 1);
		checkCodigoDaAgencia(titulo);
		checkCodigoDaAgenciaMenorOuIgualQue(titulo, 10000);
		checkParametrosBancarios(titulo, POSTO_DA_AGENCIA);
		checkNumeroDaContaNotNull(titulo);
		checkCodigoDoNumeroDaConta(titulo);
		checkCodigoDoNumeroDaContaMenorOuIgualQue(titulo, 100000);
		checkValor(titulo);
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		
		if(titulo.getContaBancaria().getCarteira().isComRegistro()){
			
			this.add(new Field<String>(COBRANCA_COM_REGISTRO, 1));
			
		}else{
			
			this.add(new Field<String>(COBRANCA_SEM_REGISTRO, 1));
		}
		
		this.add(FIELD_CARTEIRA);
		this.add(new Field<String>(titulo.getNossoNumero()+titulo.getDigitoDoNossoNumero(), 9, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		this.add(new Field<Object>(titulo.getParametrosBancarios().getValor(POSTO_DA_AGENCIA), 2, Filler.ZERO_LEFT));
		this.add(new Field<Object>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 5, Filler.ZERO_LEFT));
		
		if (titulo.getContaBancaria().getCarteira().isSemRegistro() && titulo.getValor().compareTo(ZERO) == 1) {
			
			this.add(new Field<String>("1", 1));
			
		} else {
			
			this.add(new Field<String>("0", 1));
		}

		this.add(new Field<String>("0", 1));
		this.add(new Field<Integer>(calculeDigitoVerificador(), 1));
	}
	
	 
	private void checkCarteiraSimples(Titulo titulo) {
		
		if(!titulo.getContaBancaria().getCarteira().getCodigo().equals(CARTEIRA_SIMPLES_VALUE)){
		
			throw new IllegalArgumentException(format("Apenas a carteira de código [1] \"carteira simples\" é permitida e não o código [%s]!", titulo.getContaBancaria().getCarteira().getCodigo()));
		}
	}

	 
	private Integer calculeDigitoVerificador() {

		final int resto = modulo11.calcule(writeFields());

		if (resto != 0 && resto != 1) {

			return Integer.valueOf(modulo11.valor() - resto);
			
		} else{
			
			return Integer.valueOf(resto);
		}
	}

}
