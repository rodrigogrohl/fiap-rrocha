 


package br.com.fiap.framework.campolivre;


 
public class NotSupportedCampoLivreException extends CampoLivreException {

	 
	private static final long serialVersionUID = 1L;

	 
	public NotSupportedCampoLivreException() {
		super();
	}

	 
	public NotSupportedCampoLivreException(String message, Throwable cause) {
		super(message, cause);
		
	}

	 
	public NotSupportedCampoLivreException(String message) {
		super(message);
		
	}

	 
	public NotSupportedCampoLivreException(Throwable cause) {
		super(cause);
		
	}
	
}
