 


package br.com.fiap.framework.campolivre;


 
public class NotSupportedBancoException extends CampoLivreException {

	 
	private static final long serialVersionUID = 1L;
	
	private static String msg = "Banco não suportado por não haver " +
								"implementações de Campo Livre para " +
								"o mesmo.";
	
	
	 
	public NotSupportedBancoException() {
		super(msg);
	}
	
	 
	@SuppressWarnings("unused")
	private NotSupportedBancoException(String message, Throwable cause) {
		super(message, cause);
	}
	
	 
	@SuppressWarnings("unused")
	private NotSupportedBancoException(String message) {
		super(message);
	}
	
	 
	@SuppressWarnings("unused")
	private NotSupportedBancoException(Throwable cause) {
		super(msg, cause);
	}
	
}
