
 
	
package br.com.fiap.framework;



 

public class CodigoDeBarrasException extends RuntimeException {

	 
	private static final long serialVersionUID = -3577770829101964833L;

	 
	public CodigoDeBarrasException() {
	
	}

	 
	public CodigoDeBarrasException(String message, Throwable cause) {
		super(message, cause);
	
	}

	 
	public CodigoDeBarrasException(String message) {
		super(message);
	
	}

	 
	public CodigoDeBarrasException(Throwable cause) {
		super(cause);
	
	}

}
