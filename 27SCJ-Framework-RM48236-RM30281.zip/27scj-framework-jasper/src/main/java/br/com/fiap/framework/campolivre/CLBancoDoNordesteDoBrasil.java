 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBancoDoNordesteDoBrasil extends AbstractCLBancoDoNordesteDoBrasil {
	
	 
	private static final long serialVersionUID = -6487723647496876064L;

	 
	protected static final Integer FIELDS_LENGTH = Integer.valueOf(7);

	 
	protected static final Integer AGENCIA_LENGTH = Integer.valueOf(4);

	 
	protected static final Integer CONTA_LENGTH = Integer.valueOf(7);

	 
	protected static final Integer DIGITO_CONTA_LENGTH = Integer.valueOf(1);
	

	 
	protected static final Integer NOSSO_NUMERO_LENGTH = Integer.valueOf(7);

	 
	protected static final Integer DIGITO_NOSSO_NUMERO_LENGTH = Integer.valueOf(1);
	
	 
	protected static final Integer CARTEIRA_LENGTH = Integer.valueOf(2);
	
	
	 
	protected static final Integer CAMPO_ZERADO_LENGTH = Integer.valueOf(3);
	
	 
	protected static final Integer CAMPO_ZERADO_VALUE = Integer.valueOf(0);
	
	 
	protected CLBancoDoNordesteDoBrasil() {
		super(FIELDS_LENGTH);
	}
	
	@Override
	protected void checkValues(Titulo titulo){
		
		checkAgenciaNotNull(titulo);
		checkCodigoDaAgencia(titulo);
		checkCodigoDaAgenciaMenorOuIgualQue(titulo, 9999);
		
		checkNumeroDaContaNotNull(titulo);
		checkCodigoDoNumeroDaConta(titulo);
		checkCodigoDoNumeroDaContaMenorOuIgualQue(titulo, 9999999);
		checkDigitoDoCodigoDoNumeroDaConta(titulo);

		checkNossoNumero(titulo);
		checkDigitoDoNossoNumero(titulo);

		checkCarteiraNotNull(titulo);
		checkCodigoDaCarteira(titulo);
		checkCodigoDaCarteiraMenorOuIgualQue(titulo, 99);
		
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), AGENCIA_LENGTH, Filler.ZERO_LEFT));

		this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), CONTA_LENGTH, Filler.ZERO_LEFT));
		this.add(new Field<String>(titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta(), DIGITO_CONTA_LENGTH, Filler.ZERO_LEFT));
		
		this.add(new Field<String>(titulo.getNossoNumero(), NOSSO_NUMERO_LENGTH, Filler.ZERO_LEFT));
		this.add(new Field<String>(titulo.getDigitoDoNossoNumero(), DIGITO_NOSSO_NUMERO_LENGTH, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(titulo.getContaBancaria().getCarteira().getCodigo(), CARTEIRA_LENGTH, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(CAMPO_ZERADO_VALUE, CAMPO_ZERADO_LENGTH,  Filler.ZERO_LEFT));
		
	}
}
