package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;

abstract class AbstractCLUnibanco extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -6169577742706045367L;

	 
	protected AbstractCLUnibanco(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException {

		checkCarteiraNotNull(titulo);
		checkRegistroDaCarteiraNotNull(titulo);

		switch(titulo.getContaBancaria().getCarteira().getTipoCobranca()){
		case SEM_REGISTRO:
			return new CLUnibancoCobrancaNaoRegistrada(titulo);
		case COM_REGISTRO:
			return new CLUnibancoCobrancaRegistrada(titulo);
		default:
			return null;
		}
	}

	 
	String calculeDigitoEmModulo11(String numero) {

		String dv = "";

		int soma = Modulo.calculeSomaSequencialMod11(numero, 2, 9);

		soma *= 10;

		final int resto = soma % 11;

		if (resto == 10 || resto == 0)
			dv = "0";
		else
			dv = "" + resto;

		return dv;

	}
}
