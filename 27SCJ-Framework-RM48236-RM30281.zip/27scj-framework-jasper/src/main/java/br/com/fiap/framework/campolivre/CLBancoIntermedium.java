 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;


 
class CLBancoIntermedium extends AbstractCLBancoIntermedium { 

	 
	private static final long serialVersionUID = 858563493013156459L;
	
	 
	private static final Integer FIELDS_LENGTH = 6;
	
	private static final Integer CONSTANTE_70 = Integer.valueOf(70);
	
	private static final Integer CONSTANTE_0 = Integer.valueOf(0);

	 
	CLBancoIntermedium(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(CONSTANTE_70, 2));
		this.add(new Field<String>(titulo.getNossoNumero(), 11, Filler.ZERO_LEFT));	
		this.add(new Field<Integer>( titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 6, Filler.ZERO_LEFT));
		this.add(new Field<String>( titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta(), 1, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(CONSTANTE_0, 1));
	}

	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
