 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBradesco extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -1733227746617862639L;

	 
	protected AbstractCLBradesco(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo){
		
		return new CLBradesco().build(titulo);
	}
}
