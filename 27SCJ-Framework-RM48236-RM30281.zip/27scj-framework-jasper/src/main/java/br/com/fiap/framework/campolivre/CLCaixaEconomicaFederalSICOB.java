package br.com.fiap.framework.campolivre;

import static java.lang.String.format;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLCaixaEconomicaFederalSICOB extends AbstractCLCaixaEconomicaFederal {
	
	 
	private static final long serialVersionUID = 5585190685525441426L;
	
	 
	private static final Integer FIELDS_LENGTH = 4;

	 
	CLCaixaEconomicaFederalSICOB(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		Objects.checkNotNull(titulo.getParametrosBancarios(), "Parâmetros bancários necessários [titulo.getParametrosBancarios()==null]!");
		checkPadraoNossoNumero(titulo.getNossoNumero());
		
		this.add(new Field<String>(titulo.getNossoNumero(), 10));
	
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		
		if(titulo.getParametrosBancarios().contemComNome("CodigoOperacao")){
			
			Integer cnpv = titulo.getParametrosBancarios().getValor("CodigoOperacao");
		
			Objects.checkNotNull(titulo.getParametrosBancarios(), "Parâmetro bancário código operação inválido [CodigoOperacao==null]!");
				
			this.add(new Field<Integer>(cnpv, 3, Filler.ZERO_LEFT));
			
			this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 8, Filler.ZERO_LEFT));
			
		}else{
			
			throw new CampoLivreException("Parâmetro bancário código operação (\"CodigoOperacao\") não encontrado!");
		}
		
	}
	
	 
	private void checkPadraoNossoNumero(String nn){
		
		if(!nn.startsWith("9") && !nn.startsWith("80") && !nn.startsWith("81") && !nn.startsWith("82")){
			
			throw new IllegalArgumentException(format("Para a cobrança SICOB o nosso número [%s] deve começar com 9 que é o identificador da \"carteira rápida\" [9NNNNNNNNN] ou 80, 81 e 82 para \"carteira sem registro\" [82NNNNNNNN]!", nn));
		}
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
