 

package br.com.fiap.framework;

import static org.27scj-framework-jasper.utilix.Objects.isNotNull;
import static org.27scj-framework-jasper.utilix.Objects.isNull;
import static org.27scj-framework-jasper.utilix.text.DateFormat.DDMMYYYY_B;

import java.awt.Image;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.Objects;

import br.com.fiap.framework.campolivre.CampoLivre;
import br.com.fiap.framework.campolivre.CampoLivreFactory;
import br.com.fiap.framework.campolivre.NotSupportedBancoException;
import br.com.fiap.framework.campolivre.NotSupportedCampoLivreException;

 
public final class Boleto {
	
	private static Logger log = Logger.getLogger(Boleto.class);

	 
	private Titulo titulo;
	
	 
	private Date dataDeProcessamento;
	
	 
	private CodigoDeBarras codigoDeBarras;
	
	 
	private LinhaDigitavel linhaDigitavel;
	
	 
	private CampoLivre campoLivre;
	
	 
	private String localPagamento;
	
	 
	private String instrucaoAoSacado;
	
	private String instrucao1;
	private String instrucao2;
	private String instrucao3;
	private String instrucao4;
	private String instrucao5;
	private String instrucao6;
	private String instrucao7;
	private String instrucao8;

	 
	private Map<String, String> textosExtras; 
	
	 
	private Map<String, Image> imagensExtras; 
	
	 
	public Boleto() {
		super();
	}
	
	 
	public Boleto(Titulo titulo)throws IllegalArgumentException, NotSupportedBancoException, NotSupportedCampoLivreException{

		if(log.isTraceEnabled())
			log.trace("Instanciando boleto");
		
		if(log.isDebugEnabled())
			log.debug("titulo instance : "+titulo);
		
		if(isNotNull(titulo)){
			
			this.setTitulo(titulo);
			this.setCampoLivre(CampoLivreFactory.create(titulo));
			this.load();
			
			if(log.isDebugEnabled()){
				log.debug("boleto instance : " + this);
			}
			
		}else {
			IllegalArgumentException e = new IllegalArgumentException("Título nulo!");
			log.error("Valor Não Permitido!",e);
			throw e;
		}
		
		if(log.isDebugEnabled() || log.isTraceEnabled())
			log.trace("Boleto Instanciado : "+this);

	}

	 
	public Boleto(Titulo titulo, CampoLivre campoLivre) {
		super();

		if(log.isTraceEnabled())
			log.trace("Instanciando boleto");
		
		if(log.isDebugEnabled())
			log.debug("titulo instance : "+titulo);
		
		if(log.isDebugEnabled())
			log.debug("campoLivre instance : "+campoLivre);
		
		if(isNotNull(titulo)){
			
			this.setTitulo(titulo);
			this.setCampoLivre(campoLivre);
			this.load();
			
			if(log.isDebugEnabled())
				log.debug("boleto instance : "+this);
			
		}else {
			IllegalArgumentException e = new IllegalArgumentException("Título nulo!");
			log.error("Valor Não Permitido!",e);
			throw e;
		}
		
		if(log.isDebugEnabled() || log.isTraceEnabled()){
			
			log.trace("Boleto Instanciado : "+this);
		}
		
	}

	private void load(){
		
		codigoDeBarras = new CodigoDeBarras(titulo, campoLivre);
		linhaDigitavel = new LinhaDigitavel(codigoDeBarras);
		dataDeProcessamento = new Date();
		
		if(log.isInfoEnabled()){
			
			log.info("Data de Processamento do Boleto : "+DDMMYYYY_B.format(dataDeProcessamento));
		}
	}
	
	 
	public CampoLivre getCampoLivre() {
		
		return campoLivre;
	}

	 
	private void setCampoLivre(CampoLivre campoLivre) {
		
		Objects.checkNotNull(campoLivre);
		
		int length = campoLivre.write().length();
		
		if (length == CampoLivre.STRING_LENGTH) {
			this.campoLivre = campoLivre;
			
		} else {
			
			if (length > CampoLivre.STRING_LENGTH) {
				throw new IllegalArgumentException("O tamanho da String [" + length + "] é maior que o especificado [" + CampoLivre.STRING_LENGTH + "]!");
				
			} else {
				throw new IllegalArgumentException("O tamanho da String [" + length + "] é menor que o especificado [" + CampoLivre.STRING_LENGTH + "]!");
			}
		}
	}

	 
	public Titulo getTitulo() {
		return titulo;
	}

	 
	public void setTitulo(Titulo titulo) {
		this.titulo = titulo;
	}

	 
	public Date getDataDeProcessamento() {
		return dataDeProcessamento;
	}

	 
	public void setDataDeProcessamento(Date dataDeProcessamento) {
		this.dataDeProcessamento = dataDeProcessamento;
	}

	 
	public CodigoDeBarras getCodigoDeBarras() {
		return codigoDeBarras;
	}

	 
	public void setCodigoDeBarras(CodigoDeBarras codigoDeBarras) {
		this.codigoDeBarras = codigoDeBarras;
	}

	 
	public LinhaDigitavel getLinhaDigitavel() {
		return linhaDigitavel;
	}

	 
	public void setLinhaDigitavel(LinhaDigitavel linhaDigitavel) {
		this.linhaDigitavel = linhaDigitavel;
	}

	 
	public String getLocalPagamento() {
		return localPagamento;
	}

	 
	public void setLocalPagamento(String localPagamento1) {
		this.localPagamento = localPagamento1;
	}

	 
	public String getInstrucaoAoSacado() {
		return instrucaoAoSacado;
	}

	 
	public void setInstrucaoAoSacado(String insturcaoAoSacado) {
		this.instrucaoAoSacado = insturcaoAoSacado;
	}

	 
	public String getInstrucao1() {
		return instrucao1;
	}

	 
	public void setInstrucao1(String instrucao1) {
		this.instrucao1 = instrucao1;
	}

	 
	public String getInstrucao2() {
		return instrucao2;
	}

	 
	public void setInstrucao2(String instrucao2) {
		this.instrucao2 = instrucao2;
	}

	 
	public String getInstrucao3() {
		return instrucao3;
	}

	 
	public void setInstrucao3(String instrucao3) {
		this.instrucao3 = instrucao3;
	}

	 
	public String getInstrucao4() {
		return instrucao4;
	}

	 
	public void setInstrucao4(String instrucao4) {
		this.instrucao4 = instrucao4;
	}

	 
	public String getInstrucao5() {
		return instrucao5;
	}

	 
	public void setInstrucao5(String instrucao5) {
		this.instrucao5 = instrucao5;
	}

	 
	public String getInstrucao6() {
		return instrucao6;
	}

	 
	public void setInstrucao6(String instrucao6) {
		this.instrucao6 = instrucao6;
	}

	 
	public String getInstrucao7() {
		return instrucao7;
	}

	 
	public void setInstrucao7(String instrucao7) {
		this.instrucao7 = instrucao7;
	}

	 
	public String getInstrucao8() {
		return instrucao8;
	}

	 
	public void setInstrucao8(String instrucao8) {
		this.instrucao8 = instrucao8;
	}

	public Map<String, String> getTextosExtras() {
		
		return this.textosExtras;
	}

	public void setTextosExtras(Map<String,String> textosExtras) {

		this.textosExtras = textosExtras;
	}
	
	public void addTextosExtras(String nome, String valor) {
		
		if(isNull(getTextosExtras())) {
			setTextosExtras(new HashMap<String, String>());
		}
		
		getTextosExtras().put(nome, valor);
	}
	
	public Map<String, Image> getImagensExtras() {
		return this.imagensExtras;
	}

	public void setImagensExtras(Map<String,Image> imagensExtras) {
		this.imagensExtras = imagensExtras;
	}
	
	public void addImagensExtras(String fieldName, Image image) {
		
		if(isNull(getImagensExtras())) {
			setImagensExtras(new HashMap<String, Image>());
		}
		
		getImagensExtras().put(fieldName, image);
	}

	@Override
	public String toString() {
		return Objects.toString(this);
	}
}
