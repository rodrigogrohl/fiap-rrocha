 

package br.com.fiap.framework;

import java.io.Serializable;
import java.util.HashMap;

import org.27scj-framework-jasper.domkee.comum.pessoa.id.cprf.CNPJ;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Banco;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.CodigoDeCompensacaoBACEN;

 
public enum BancosSuportados implements Serializable{

	 

	 
	BANCO_DO_BRASIL("001", "00000000000191", "BANCO DO BRASIL S.A.", "Banco do Brasil - Banco Múltiplo"),
		
	 	
	BANCO_DO_NORDESTE_DO_BRASIL("004","07237373000120", "BANCO DO NORDESTE DO BRASIL S.A.","Banco Múltiplo"),		
	
	 
	BANCO_DO_ESTADO_DO_ESPIRITO_SANTO("021", "28127603000178", "BANCO DO ESTADO DO ESPIRITO SANTO S.A.", "Banco Múltiplo"),
			
	 
	BANCO_SANTANDER("033", "90400888000142", "Banco Santander (Brasil) S. A.", "Banco Mútiplo"),

	 
	BANCO_DO_ESTADO_DO_RIO_GRANDE_DO_SUL("041", "92702067000196", "BANCO DO ESTADO DO RIO GRANDE DO SUL S.A.", "Banco Múltiplo"),
			
	 
	BANCO_INTEMEDIUM("077", "00416968000101", "BANCO INTERMEDIUM S.A.", "Banco Múltiplo"),	
			
	 
	CAIXA_ECONOMICA_FEDERAL("104", "00360305000104", "CAIXA ECONOMICA FEDERAL", "Caixa Econômica Federal"),

	 
	NOSSA_CAIXA("151", "43073394000110", "BANCO NOSSA CAIXA S.A.", "Banco Múltiplo"),	
			
	 
	BANCO_BRADESCO("237", "60746948000112", "BANCO BRADESCO S.A.", "Banco Múltiplo"),

	 
	BANCO_ITAU("341", "60701190000104", "BANCO ITAÚ S.A.", "Banco Múltiplo"),

	 
	BANCO_ABN_AMRO_REAL("356", "33066408000115", "BANCO ABN AMRO REAL S.A.", "Banco Múltiplo"),

	 
	MERCANTIL_DO_BRASIL("389", "17184037000110", "BANCO MERCANTIL DO BRASIL S.A.", "Banco Múltiplo"),
			
	 
	HSBC("399", "01701201000189", "HSBC BANK BRASIL S.A.", "Banco Múltiplo"),

	 
	UNIBANCO("409", "33700394000140", "UNIBANCO-UNIAO DE BANCOS BRASILEIROS S.A.", "Banco Múltiplo"),

	 
	BANCO_SAFRA("422", "58160789000128", "BANCO SAFRA S.A.", "Banco Múltiplo"),
	
	 
	BANCO_RURAL("453", "58160789000128", "BANCO RURAL S.A.", "Banco Múltiplo"),
	
	 
	BANCO_fiapI("748", "01181521000155", "BANCO COOPERATIVO fiapI S.A.", "Banco Mútiplo Cooperativo"),
	
	;

	 
	public static final HashMap<String, BancosSuportados> suportados = new HashMap<String, BancosSuportados>(
			BancosSuportados.values().length);

	static {

		suportados.put(BANCO_DO_BRASIL.codigoDeCompensacaoBACEN, BANCO_DO_BRASIL);

		suportados.put(BANCO_DO_NORDESTE_DO_BRASIL.codigoDeCompensacaoBACEN, BANCO_DO_NORDESTE_DO_BRASIL);

		suportados.put(CAIXA_ECONOMICA_FEDERAL.codigoDeCompensacaoBACEN, CAIXA_ECONOMICA_FEDERAL);

		suportados.put(BANCO_BRADESCO.codigoDeCompensacaoBACEN, BANCO_BRADESCO);

		suportados.put(BANCO_ABN_AMRO_REAL.codigoDeCompensacaoBACEN, BANCO_ABN_AMRO_REAL);

		suportados.put(UNIBANCO.codigoDeCompensacaoBACEN, UNIBANCO);

		suportados.put(HSBC.codigoDeCompensacaoBACEN, HSBC);

		suportados.put(BANCO_ITAU.codigoDeCompensacaoBACEN, BANCO_ITAU);

		suportados.put(BANCO_SAFRA.codigoDeCompensacaoBACEN, BANCO_SAFRA);
		
		suportados.put(BANCO_DO_ESTADO_DO_RIO_GRANDE_DO_SUL.codigoDeCompensacaoBACEN, BANCO_DO_ESTADO_DO_RIO_GRANDE_DO_SUL);
		
		suportados.put(MERCANTIL_DO_BRASIL.codigoDeCompensacaoBACEN, MERCANTIL_DO_BRASIL);
		
		suportados.put(NOSSA_CAIXA.codigoDeCompensacaoBACEN, NOSSA_CAIXA);
		
		suportados.put(BANCO_DO_ESTADO_DO_ESPIRITO_SANTO.codigoDeCompensacaoBACEN, BANCO_DO_ESTADO_DO_ESPIRITO_SANTO);
		
		suportados.put(BANCO_RURAL.codigoDeCompensacaoBACEN, BANCO_RURAL);
		
		suportados.put(BANCO_SANTANDER.codigoDeCompensacaoBACEN, BANCO_SANTANDER);
		
		suportados.put(BANCO_INTEMEDIUM.codigoDeCompensacaoBACEN, BANCO_INTEMEDIUM);

		suportados.put(BANCO_fiapI.codigoDeCompensacaoBACEN, BANCO_fiapI);
	}

	 
	private String codigoDeCompensacaoBACEN;

	 
	private String cNPJ;

	 
	private String instituicao;

	 
	private String segmento;

	 
	private BancosSuportados(String codigoDeCompensacaoBACEN, String cnpj,
			String instituicao, String segmento) {
		
		this.codigoDeCompensacaoBACEN = codigoDeCompensacaoBACEN;
		this.cNPJ = cnpj;
		this.instituicao = instituicao;
		this.segmento = segmento;
	}
	
	
	 
	public static boolean isSuportado(String codigoDeCompensacao) {
		return suportados.containsKey(codigoDeCompensacao);
	}

	 
	public Banco create() {
		return new Banco(new CodigoDeCompensacaoBACEN(this.codigoDeCompensacaoBACEN), this.instituicao, new CNPJ(
				this.cNPJ), this.segmento);
	}

	 
	public String getCodigoDeCompensacao() {
		return codigoDeCompensacaoBACEN;
	}

	 
	public String getCNPJ() {
		return cNPJ;
	}

	 
	public String getInstituicao() {
		return instituicao;
	}

	 
	public String getSegmento() {
		return segmento;
	}
}