package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBancoRural extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -602454445158254612L;

	 
	static final String CODIGO_REDUZIDO = "CODIGO_REDUZIDO";

	 
	protected AbstractCLBancoRural(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) {
		
		checkCarteiraNotNull(titulo);
		checkRegistroDaCarteiraNotNull(titulo);
		
		switch(titulo.getContaBancaria().getCarteira().getTipoCobranca()){
		case SEM_REGISTRO:
			return campoSemRegistro(titulo);
		case COM_REGISTRO:
			return new CLBancoRuralCobrancaRegistrada(titulo);
		default:
			return null;
		}
	}

	 
	private static CampoLivre campoSemRegistro(Titulo titulo) {
		
		checkNossoNumero(titulo);
		
		switch(titulo.getNossoNumero().length()){
		case NN10:
			return new CLBancoRuralCobrancaNaoRegistradaSeguradora(titulo);
		case NN15:
			return new CLBancoRuralCobrancaNaoRegistrada(titulo);
		default:
			throw new NotSupportedCampoLivreException(
					"Combrança sem registro com campo livre diponível somente para títulos com nosso número" 
					+ " composto por 10 posições(apólice de seguro com I.O.S.) e 15 posições(padrão)."
				);
		}
	}
}
