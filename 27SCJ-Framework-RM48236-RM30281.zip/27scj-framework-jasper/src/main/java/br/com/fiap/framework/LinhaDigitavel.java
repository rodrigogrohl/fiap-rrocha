 


package br.com.fiap.framework;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.AbstractLineOfFields;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Strings;
import org.27scj-framework-jasper.vallia.digitoverificador.BoletoLinhaDigitavelDV;


 
public final class LinhaDigitavel extends AbstractLineOfFields {
	
	 
	private static final long serialVersionUID = -6089634012523938802L;
	
	private static Logger log = Logger.getLogger(LinhaDigitavel.class);
	
	 
	private static final Integer FIELDS_LENGTH = 5;
	
	 
	private static final Integer STRING_LENGTH = 54;

	 
	private Field<InnerCampo1> innerCampo1;
	
	 
	private Field<InnerCampo2> innerCampo2;
	
	 
	private Field<InnerCampo3> innerCampo3;
	
	 
	private Field<Integer> campo4;
	
	 
	private Field<InnerCampo5> innerCampo5;


	 
	LinhaDigitavel(CodigoDeBarras codigoDeBarras) {
		super(FIELDS_LENGTH,STRING_LENGTH);
		
		if(log.isTraceEnabled())
			log.trace("Instanciando Linha Digitável");
		
		if(log.isDebugEnabled())
			log.debug("codigoDeBarra instance : "+codigoDeBarras);
		
		innerCampo1 = new Field<InnerCampo1>(new InnerCampo1(4,11),11);
		innerCampo2 = new Field<InnerCampo2>(new InnerCampo2(2,12),12);
		innerCampo3 = new Field<InnerCampo3>(new InnerCampo3(2,12),12);
		campo4 = new Field<Integer>(new Integer(0),1);
		innerCampo5 = new Field<InnerCampo5>(new InnerCampo5(2,14),14);
		
		add(innerCampo1);
		add(innerCampo2);
		add(innerCampo3);
		add(campo4);
		add(innerCampo5);
		
		this.innerCampo1.getValue().load(codigoDeBarras);
		this.innerCampo2.getValue().load(codigoDeBarras);
		this.innerCampo3.getValue().load(codigoDeBarras);
		
		this.campo4.setValue(codigoDeBarras.getDigitoVerificadorGeral().getValue());
		
		if(log.isDebugEnabled())
			log.debug("InnerCampo 4 da Linha Digitável : "+this.campo4.getValue());
		
		this.innerCampo5.getValue().load(codigoDeBarras);
		
		if(log.isDebugEnabled() || log.isTraceEnabled())
			log.debug("linhaDigitavel instanciada : "+this.write());
	}

	 
	@Override
	public String write(){
		
		return new StringBuilder(innerCampo1.write()).
		append(Strings.WHITE_SPACE).
		append(innerCampo2.write()).
		append(Strings.WHITE_SPACE).
		append(innerCampo3.write()).
		append(Strings.WHITE_SPACE).
		append(campo4.write()).
		append(Strings.WHITE_SPACE).
		append(innerCampo5.write()).toString();

	}

	private abstract class InnerCampo extends AbstractLineOfFields {
		
		 
		private static final long serialVersionUID = 6746400538765124943L;
		 
		protected final BoletoLinhaDigitavelDV calculadorDV = new BoletoLinhaDigitavelDV();
		
		
		protected InnerCampo(Integer fieldsLength, Integer stringLength) {
			super(fieldsLength, stringLength);
		}
		
	}
	
	private abstract class InnerCampoFormatado extends InnerCampo {
		
		
		 
		private static final long serialVersionUID = 3650450185403697045L;

		protected InnerCampoFormatado(final Integer fieldsLength, final Integer stringLength) {
			super(fieldsLength, stringLength);
		}
		
		 
		@Override
		public String write(){
			
			StringBuilder lineOfFields = new StringBuilder(StringUtils.EMPTY);
			
			for(Field<?> field : this)
				lineOfFields.append(field.write());
			
			lineOfFields.insert(5, ".");
			
			isConsistent(lineOfFields);
			
			return lineOfFields.toString();
		}
		
	}
	
	 
	private class InnerCampo1 extends InnerCampoFormatado{
		
		 
		private static final long serialVersionUID = 2948116051922000890L;

		 
		private InnerCampo1(Integer fieldsLength, Integer stringLength) {
			super(fieldsLength, stringLength);
		}
		
		 
		private void load(CodigoDeBarras codigoDeBarras){
				
				if(log.isTraceEnabled())
					log.trace("Compondo campo 1 da Linha Digitável");

				add(new Field<String>(codigoDeBarras.write().substring(0, 3),3));
				add(new Field<String>(codigoDeBarras.write().substring(3, 4),1));
				add(new Field<String>(codigoDeBarras.write().substring(19, 24),5));				
				add(new Field<Integer>(calculadorDV.calcule(get(0).write() + get(1).write() + get(2).write()),1));
				
				if(log.isDebugEnabled())
					log.debug("Digito verificador do Field 1 da Linha Digitável : "+get(3).getValue());

				
				if(log.isDebugEnabled() || log.isTraceEnabled())
					log.debug("Field 1 da Linha Digitável composto : "+write());
		}
		
	}
	
	 
	private class InnerCampo2 extends InnerCampoFormatado{

		 
		private static final long serialVersionUID = -2201847536243988819L;

		 
		private InnerCampo2(Integer fieldsLength, Integer stringLength) {
			super(fieldsLength, stringLength);
		}
		
		
		 
		private void load(CodigoDeBarras codigoDeBarras){
			
			if(log.isTraceEnabled())
				log.trace("Compondo campo 2 da Linha Digitável");
			
			add(new Field<String>(codigoDeBarras.write().substring(24, 34),10));				
			add(new Field<Integer>(calculadorDV.calcule(get(0).write()),1));
			
			if(log.isDebugEnabled())
				log.debug("Digito verificador do campo 2 da Linha Digitável : "+get(1).getValue());
			
			if(log.isDebugEnabled() || log.isTraceEnabled())
				log.debug("InnerCampo 2 da Linha Digitável composto : "+write());
		}
		
	}
	
	 
	private class InnerCampo3 extends InnerCampoFormatado{
		
		 
		private static final long serialVersionUID = -4248472044788156665L;

		 
		private InnerCampo3(Integer fieldsLength, Integer stringLength) {
			super(fieldsLength, stringLength);
		}
		
		 
		private void load(CodigoDeBarras codigoDeBarras){
			
			if(log.isTraceEnabled())
				log.trace("Compondo campo 3 da Linha Digitável");
			
			add(new Field<String>(codigoDeBarras.write().substring(34, 44),10));				
			add(new Field<Integer>(calculadorDV.calcule(get(0).write()),1));
			
			if(log.isDebugEnabled())
				log.debug("Digito verificador do campo 3 da Linha Digitável : "+get(1).getValue());
			
			if(log.isDebugEnabled() || log.isTraceEnabled())
				log.debug("InnerCampo 3 da Linha Digitável composto : "+write());
			
		}
		
	}
	
	 
	private class InnerCampo5 extends InnerCampo{

		 
		private static final long serialVersionUID = -8040082112684009827L;

		 
		private InnerCampo5(Integer fieldsLength, Integer stringLength) {
			super(fieldsLength, stringLength);
		}
		
		 
		private void load(CodigoDeBarras codigoDeBarras){
			
			if(log.isTraceEnabled())
				log.trace("Compondo campo 5 da Linha Digitável");
			
			add(new Field<String>(codigoDeBarras.write().substring(5, 9),4));
			add(new Field<String>(codigoDeBarras.write().substring(9, 19),10));
			
			if(log.isDebugEnabled() || log.isTraceEnabled())
				log.debug("InnerCampo 5 da Linha Digitável composto : "+write());
			
		}
		
	}

	@Override
	public String toString() {
		return Objects.toString(this);
	}
}
