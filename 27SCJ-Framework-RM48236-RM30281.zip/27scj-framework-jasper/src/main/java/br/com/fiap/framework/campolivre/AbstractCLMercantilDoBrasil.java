 
package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLMercantilDoBrasil extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -6705784312499730452L;

	 
	protected AbstractCLMercantilDoBrasil(Integer fieldsLength) {
		
		super(fieldsLength);
	}
	
	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException {

		return new CLMercantilDoBrasil(titulo);
	}
}
