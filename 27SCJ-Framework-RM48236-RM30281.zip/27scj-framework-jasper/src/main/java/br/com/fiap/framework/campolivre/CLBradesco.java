 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBradesco extends AbstractCLBradesco {
	
	 
	private static final long serialVersionUID = -1253549781074159862L;

	 
	protected static final Integer FIELDS_LENGTH = Integer.valueOf(5);

	 
	protected static final Integer AGENCIA_LENGTH = Integer.valueOf(4);
	
	 
	protected static final Integer CARTEIRA_LENGTH = Integer.valueOf(2);
	
	 
	protected static final Integer NOSSO_NUMERO_LENGTH = Integer.valueOf(11);
	
	 
	protected static final Integer CONTA_LENGTH = Integer.valueOf(7);
	
	 
	protected static final Integer CONSTANTE_LENGTH = Integer.valueOf(1);
	
	 
	protected static final Integer CONSTANTE_VALUE = Integer.valueOf(0);
	
	 
	protected CLBradesco() {
		
		super(FIELDS_LENGTH);
	}
	
	@Override
	protected void checkValues(Titulo titulo){
		
		checkAgenciaNotNull(titulo);
		checkCodigoDaAgencia(titulo);//necessario caso seja uma interface
		checkCodigoDaAgenciaMenorOuIgualQue(titulo, 9999);
		checkCarteiraNotNull(titulo);
		checkCodigoDaCarteira(titulo);
		checkCodigoDaCarteiraMenorOuIgualQue(titulo, 99);
		checkNossoNumero(titulo);
		checkTamanhoDoNossoNumero(titulo, NN11);
		checkNumeroDaContaNotNull(titulo);
		checkCodigoDoNumeroDaConta(titulo);
		checkCodigoDoNumeroDaContaMenorOuIgualQue(titulo, 9999999);
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), AGENCIA_LENGTH, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getCarteira().getCodigo(), CARTEIRA_LENGTH, Filler.ZERO_LEFT));
		this.add(new Field<String>(titulo.getNossoNumero(), NOSSO_NUMERO_LENGTH, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), CONTA_LENGTH, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(CONSTANTE_VALUE, CONSTANTE_LENGTH));
	}
}
