 
package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLNossaCaixa extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = 3806982587407010815L;

	 
	protected AbstractCLNossaCaixa(Integer fieldsLength) {
		
		super(fieldsLength);
	}
	
	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException {
					
		return new CLNossaCaixa(titulo);
	}
}
