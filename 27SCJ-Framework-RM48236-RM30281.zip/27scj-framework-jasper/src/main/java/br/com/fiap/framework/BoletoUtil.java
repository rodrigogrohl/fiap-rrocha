 


package br.com.fiap.framework;

import static org.apache.commons.lang.StringUtils.EMPTY;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.apache.commons.lang.StringUtils.trim;
import static org.27scj-framework-jasper.utilix.Objects.checkNotNull;
import static org.27scj-framework-jasper.utilix.text.Strings.WHITE_SPACE;

import org.27scj-framework-jasper.vallia.digitoverificador.BoletoLinhaDigitavelDV;

 
public final class BoletoUtil {

	 
	private static final String CODIGO_DE_BARRAS_REGEX = "\\d{44}";
	private static final String LINHA_DIGITAVEL_NUMERICA_REGEX = "\\d{47}";
	private static final String LINHA_DIGITAVEL_FORMATADA_REGEX = "\\d{5}\\.\\d{5} \\d{5}\\.\\d{6} \\d{5}\\.\\d{6} \\d{1} \\d{14}";
	 
	private static final String MSG_CODIGO_DE_BARRAS = "Código de barras inválido!";
	private static final String MSG_LINHA_INVALIDA = "Linha digitável inválida!";
	private static final String MSG_STR_VAZIA = "String vazia [ \"%s\" ] tamanho [ %d ].";
	private static final String MSG_NAO_FORMATADA = "String formatada [ \"%s\" ] de tamanho [ %d ] está fora do padrão [ \"ddddd.ddddd ddddd.dddddd ddddd.dddddd d dddddddddddddd\" ] tamanho = 54.";
	private static final String MSG_STR_NUMERICA = "String numérica [ \"%s\" ] de tamanho [ %d ] está fora do padrão [ \"ddddddddddddddddddddddddddddddddddddddddddddddd\" ] tamanho = 47.";

	 
	private BoletoUtil(){

		throw new AssertionError("NOT SUPORTED OPERATION!");
	}
	
	 
	public static String getCampoLivreDaLinhaDigitavelFormatada(
			String linhaDigitavel) throws 
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		final String linhaNumerica = linhaDigitavelFormatadaEmNumerica(linhaDigitavel);

		return new StringBuilder().append(linhaNumerica.substring(4, 9))
				.append(linhaNumerica.substring(10, 20)).append(
						linhaNumerica.substring(21, 31)).toString();
	}

	 
	public static String getValorDoTituloDaLinhaDigitavelFormatada(
			String linhaDigitavel) throws 
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		return linhaDigitavelFormatadaEmNumerica(linhaDigitavel).substring(37,
				47);
	}

	 
	public static String getFatorDeVencimentoDaLinhaDigitavelFormatada(
			String linhaDigitavel) throws 
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		return linhaDigitavelFormatadaEmNumerica(linhaDigitavel).substring(33,
				37);
	}

	 
	public static String getDigitoVerificadorGeralDaLinhaDigitavelFormatada(
			String linhaDigitavel) throws 
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		return linhaDigitavelFormatadaEmNumerica(linhaDigitavel).substring(32,
				33);
	}

	 
	public static String getCodigoDaMoedaDaLinhaDigitavelFormatada(
			String linhaDigitavel) throws 
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		return linhaDigitavelFormatadaEmNumerica(linhaDigitavel)
				.substring(3, 4);
	}

	 
	public static String getCodigoDoBancoDaLinhaDigitavelFormatada(
			String linhaDigitavel) throws 
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		return linhaDigitavelFormatadaEmNumerica(linhaDigitavel)
				.substring(0, 3);
	}

	 
	public static String getCampoLivreDoCodigoDeBarras(
			String codigoDeBarras) throws 
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		return trim(codigoDeBarras).substring(19, 44);
	}

	 
	public static String getValorDoTituloDoCodigoDeBarras(
			String codigoDeBarras) throws 
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		return trim(codigoDeBarras).substring(9, 19);
	}

	 
	public static String getFatorDeVencimentoDoCodigoDeBarras(
			String codigoDeBarras) throws 
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		return trim(codigoDeBarras).substring(5, 9);
	}

	 
	public static String getDigitoVerificadorGeralDoCodigoDeBarras(
			String codigoDeBarras) throws 
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		return trim(codigoDeBarras).substring(4, 5);
	}

	 
	public static String getCodigoDaMoedaDoCodigoDeBarras(
			String codigoDeBarras) throws 
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		return trim(codigoDeBarras).substring(3, 4);
	}

	 
	public static String getCodigoDoBancoDoCodigoDeBarras(
			String codigoDeBarras) throws 
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		return trim(codigoDeBarras).substring(0, 3);
	}

	 
	public static String codigoDeBarrasEmLinhaDigitavelFormatada(
			String codigoDeBarras) throws
			IllegalArgumentException, CodigoDeBarrasException {

		return linhaDigitavelNumericaEmFormatada(codigoDeBarrasEmLinhaDigitavelNumerica(codigoDeBarras));
	}

	 
	public static String codigoDeBarrasEmLinhaDigitavelNumerica(
			String codigoDeBarras) throws
			IllegalArgumentException, CodigoDeBarrasException {

		checkFormatoCodigoDeBarras(codigoDeBarras);

		final BoletoLinhaDigitavelDV calculadorDV = new BoletoLinhaDigitavelDV();

		final StringBuilder linhaDigitavel = new StringBuilder();

		final String c = trim(codigoDeBarras);

		// campo1
		// banco
		linhaDigitavel.append(c.substring(0, 3));
		// moeda
		linhaDigitavel.append(c.substring(3, 4));
		linhaDigitavel.append(c.substring(19, 24));
		linhaDigitavel.append(calculadorDV.calcule(linhaDigitavel.toString()));

		// campo2
		linhaDigitavel.append(c.substring(24, 34));
		linhaDigitavel.append(calculadorDV.calcule(c.substring(24, 34)));

		// campo3
		linhaDigitavel.append(c.substring(34, 44));
		linhaDigitavel.append(calculadorDV.calcule(c.substring(34, 44)));

		// campo4=DV_Geral
		linhaDigitavel.append(c.substring(4, 5));

		// campo5
		linhaDigitavel.append(c.substring(5, 19));

		return linhaDigitavel.toString();
	}

	 
	public static String linhaDigitavelFormatadaEmCodigoDeBarras(
			String linhaDigitavel) throws
			IllegalArgumentException, LinhaDigitavelException {

		return linhaDigitavelNumericaEmCodigoDeBarras(linhaDigitavelFormatadaEmNumerica(linhaDigitavel));
	}

	 
	public static String linhaDigitavelNumericaEmCodigoDeBarras(
			String linhaDigitavel) throws
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelNumerica(linhaDigitavel);

		final StringBuilder codigoDeBarras = new StringBuilder();

		final String l = trim(linhaDigitavel);

		// banco
		codigoDeBarras.append(l.substring(0, 3));
		// moeda
		codigoDeBarras.append(l.substring(3, 4));

		codigoDeBarras.append(l.substring(32, 33));
		codigoDeBarras.append(l.substring(33, 47));
		codigoDeBarras.append(l.substring(4, 9));
		codigoDeBarras.append(l.substring(10, 20));
		codigoDeBarras.append(l.substring(21, 31));

		return codigoDeBarras.toString();
	}

	 
	public static String linhaDigitavelFormatadaEmNumerica(
			String linhaDigitavel) throws IllegalArgumentException,
			LinhaDigitavelException {

		checkFormatoLinhaDigitavelFormatada(linhaDigitavel);

		return linhaDigitavel.replaceAll(WHITE_SPACE, EMPTY).replaceAll("\\.",
				EMPTY);
	}

	 
	public static String linhaDigitavelNumericaEmFormatada(
			String linhaDigitavel) throws
			IllegalArgumentException, LinhaDigitavelException {

		checkFormatoLinhaDigitavelNumerica(linhaDigitavel);

		final StringBuilder linhaFormatada = new StringBuilder();

		final String l = trim(linhaDigitavel);

		linhaFormatada.append(l.substring(0, 5));
		linhaFormatada.append(".");
		linhaFormatada.append(l.substring(5, 10));
		linhaFormatada.append(WHITE_SPACE);
		linhaFormatada.append(l.substring(10, 15));
		linhaFormatada.append(".");
		linhaFormatada.append(l.substring(15, 21));
		linhaFormatada.append(WHITE_SPACE);
		linhaFormatada.append(l.substring(21, 26));
		linhaFormatada.append(".");
		linhaFormatada.append(l.substring(26, 32));
		linhaFormatada.append(WHITE_SPACE);
		linhaFormatada.append(l.substring(32, 33));
		linhaFormatada.append(WHITE_SPACE);
		linhaFormatada.append(l.substring(33));

		return linhaFormatada.toString();
	}

	 
	public static boolean isCodigoDeBarrasValido(String codigoDeBarras) {

		if (isNotBlank(codigoDeBarras)) {

			return codigoDeBarras.trim().matches(CODIGO_DE_BARRAS_REGEX);
		} else {

			return false;
		}
	}

	 
	public static boolean isLinhaDigitavelFormatadaValida(
			String linhaDigitavel) {

		if (isNotBlank(linhaDigitavel)) {

			return linhaDigitavel.trim().matches(
					LINHA_DIGITAVEL_FORMATADA_REGEX);
		} else {

			return false;
		}
	}

	 
	public static boolean isLinhaDigitavelNumericaValida(
			String linhaDigitavel) {

		if (isNotBlank(linhaDigitavel)) {

			return linhaDigitavel.trim()
					.matches(LINHA_DIGITAVEL_NUMERICA_REGEX);
		} else {

			return false;
		}
	}

	 
	public static void checkFormatoLinhaDigitavelFormatada(
			String linhaDigitavel) throws
			IllegalArgumentException, LinhaDigitavelException {

		checkExistsLinhaDigitavel(linhaDigitavel);

		if (!linhaDigitavel.contains(".")) {
			throw new LinhaDigitavelException(MSG_LINHA_INVALIDA
					+ " "
					+ String.format(MSG_NAO_FORMATADA, linhaDigitavel,
							linhaDigitavel.length())
					+ " A linha digitável formatada deve conter pontos!");
		}

		if (!linhaDigitavel.trim().contains(" ")) {
			throw new LinhaDigitavelException(MSG_LINHA_INVALIDA
					+ " "
					+ String.format(MSG_NAO_FORMATADA, linhaDigitavel,
							linhaDigitavel.length())
					+ " A linha digitável formatada deve conter espaços!");
		}

		if (!isLinhaDigitavelFormatadaValida(linhaDigitavel)) {
			throw new LinhaDigitavelException(MSG_LINHA_INVALIDA
					+ " "
					+ String.format(MSG_NAO_FORMATADA, linhaDigitavel,
							linhaDigitavel.length()));
		}
	}

	 
	public static void checkFormatoLinhaDigitavelNumerica(
			String linhaDigitavel) throws
			IllegalArgumentException, LinhaDigitavelException {

		checkExistsLinhaDigitavel(linhaDigitavel);

		if (!isLinhaDigitavelNumericaValida(linhaDigitavel)) {
			throw new LinhaDigitavelException(MSG_LINHA_INVALIDA
					+ " "
					+ String.format(MSG_STR_NUMERICA, linhaDigitavel,
							linhaDigitavel.length())
					+ " A linha deve conter apenas 47 dígitos númericos [0-9]!");
		}

	}

	 
	public static void checkFormatoCodigoDeBarras(String codigoDeBarras)
			throws IllegalArgumentException,
			CodigoDeBarrasException {

		checkExistsCodigoDeBarras(codigoDeBarras);

		if (!isCodigoDeBarrasValido(codigoDeBarras)) {
			throw new CodigoDeBarrasException(
					MSG_CODIGO_DE_BARRAS
							+ " "
							+ String.format(MSG_STR_NUMERICA, codigoDeBarras,
									codigoDeBarras.length())
							+ " O código de barras deve conter apenas 44 dígitos númericos [0-9]!");
		}

	}

	 
	public static void checkExistsLinhaDigitavel(String linhaDigitavel)
			throws IllegalArgumentException {

		checkNotNull(linhaDigitavel, MSG_LINHA_INVALIDA);

		if (isBlank(linhaDigitavel)) {
			throw new IllegalArgumentException(MSG_LINHA_INVALIDA
					+ " "
					+ String.format(MSG_STR_VAZIA, linhaDigitavel,
							linhaDigitavel.length()));
		}
	}

	 
	public static void checkExistsCodigoDeBarras(String codigoDeBarras)
			throws IllegalArgumentException {

		checkNotNull(codigoDeBarras, MSG_LINHA_INVALIDA);

		if (isBlank(codigoDeBarras)) {
			throw new IllegalArgumentException(MSG_CODIGO_DE_BARRAS
					+ " "
					+ String.format(MSG_STR_VAZIA, codigoDeBarras,
							codigoDeBarras.length()));
		}
	}
}
