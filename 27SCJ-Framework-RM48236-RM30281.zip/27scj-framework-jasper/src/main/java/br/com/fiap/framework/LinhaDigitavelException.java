
 
	
package br.com.fiap.framework;



 
public class LinhaDigitavelException extends RuntimeException {

	 
	private static final long serialVersionUID = 8206303471509231915L;

	 
	public LinhaDigitavelException() {
		
	}

	 
	public LinhaDigitavelException(String message, Throwable cause) {
		super(message, cause);
		
	}

	 
	public LinhaDigitavelException(String message) {
		super(message);
		
	}

	 
	public LinhaDigitavelException(Throwable cause) {
		super(cause);
		
	}

}
