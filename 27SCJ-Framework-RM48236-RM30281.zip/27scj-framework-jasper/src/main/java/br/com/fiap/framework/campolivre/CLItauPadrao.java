 

package br.com.fiap.framework.campolivre;

import java.util.Arrays;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLItauPadrao extends AbstractCLItau {

	 
	private static final long serialVersionUID = 1544486299245786533L;
	
	 
	private static final Integer FIELDS_LENGTH = 7;

	 
	public CLItauPadrao(Titulo titulo) {
		super(FIELDS_LENGTH);
		
		ContaBancaria conta = titulo.getContaBancaria();
		
		this.add(new Field<Integer>(conta.getCarteira().getCodigo(), 3, Filler.ZERO_LEFT));
		this.add(new Field<String>(titulo.getNossoNumero(), 8, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(calculeDigitoDaPosicao31(
									conta.getAgencia().getCodigo(), 
									conta.getNumeroDaConta().getCodigoDaConta(), 
									conta.getCarteira().getCodigo(), 
									titulo.getNossoNumero()), 1));
		
		this.add(new Field<Integer>(conta.getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(conta.getNumeroDaConta().getCodigoDaConta(), 5, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(calculeDigitoDaPosicao41(
									conta.getAgencia().getCodigo(), 
									conta.getNumeroDaConta().getCodigoDaConta()), 1));
		
		this.add(new Field<String>("000", 3));
	}
	
	 
	private Integer calculeDigitoDaPosicao31(Integer codigoDaAgencia,
			Integer codigoDaConta, Integer codigoDaCarteira, String nossoNumero) {

		Integer[] carteirasExcecao = {126, 131, 146, 150, 168};
		StringBuilder campo = new StringBuilder();
		
		campo.append(Filler.ZERO_LEFT.fill(codigoDaCarteira.intValue(), 3));
		campo.append(Filler.ZERO_LEFT.fill(nossoNumero, 8));
		
		 
		if(Arrays.binarySearch(carteirasExcecao, codigoDaCarteira) < 0) {
			
			campo.insert(0, Filler.ZERO_LEFT.fill(codigoDaConta.intValue(), 5));
			campo.insert(0, Filler.ZERO_LEFT.fill(codigoDaAgencia.intValue(), 4));
		}
		
		return calculeDigitoVerificador(campo.toString());
	}
	
	 
	private Integer calculeDigitoDaPosicao41(Integer codigoDaAgencia,
			Integer codigoDaConta) {

		StringBuilder campo = new StringBuilder();
		campo.append(Filler.ZERO_LEFT.fill(codigoDaAgencia.intValue(), 4));
		campo.append(Filler.ZERO_LEFT.fill(codigoDaConta.intValue(), 5));
		
		return calculeDigitoVerificador(campo.toString());
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}

