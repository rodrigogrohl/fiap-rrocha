
package br.com.fiap.framework.campolivre;

import static java.lang.String.format;
import static java.math.BigDecimal.ZERO;
import static org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Banco.isCodigoDeCompensacaoOK;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.AbstractLineOfFields;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Strings;

import br.com.fiap.framework.BancosSuportados;

abstract class AbstractCampoLivre extends AbstractLineOfFields implements CampoLivre {

	 
	private static final long serialVersionUID = 4605730904122445595L;
	
	 
	private static Logger log = Logger.getLogger(Objects.class);
	
	 
	static final int NN7 = 7;

	 
	static final int NN8 = 8;
	
	 
	static final int NN9 = 9;
	
	 
	static final int NN10 = 10;
	
	 
	static final int NN11 = 11;
	
	 
	static final int NN15 = 15;
	
	 
	static final int NN17 = 17;

	 
	private AbstractCampoLivre(Integer fieldsLength, Integer stringLength) {
		
		super(fieldsLength, stringLength);
	}
	
	 
	protected AbstractCampoLivre(Integer fieldsLength) {
		
		super (fieldsLength, CampoLivre.STRING_LENGTH);
	}

	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedBancoException,
			NotSupportedCampoLivreException, CampoLivreException {

		if (log.isTraceEnabled()){
			
			log.trace("Instanciando Campo livre");
		}
		if (log.isDebugEnabled()){
			
			log.debug("titulo instance : " + titulo);
		}

		try{
		
			checkTituloNotNull(titulo);
			checkContaBancariaNotNull(titulo);
			checkBancoNotNull(titulo);
			
			if (log.isDebugEnabled()){
				
				log.debug(format("Campo Livre do Banco: %s", titulo.getContaBancaria().getBanco().getNome()));
			}
			
			if (BancosSuportados.isSuportado(titulo.getContaBancaria().getBanco().getCodigoDeCompensacaoBACEN().getCodigoFormatado())) {

				final BancosSuportados banco = BancosSuportados.suportados.get( titulo.getContaBancaria().getBanco().getCodigoDeCompensacaoBACEN().getCodigoFormatado());

				switch (banco) {

					case BANCO_BRADESCO:
						return AbstractCLBradesco.create(titulo);
					
					case BANCO_DO_BRASIL:
						return AbstractCLBancoDoBrasil.create(titulo);
	
					case BANCO_DO_NORDESTE_DO_BRASIL:
						return AbstractCLBancoDoNordesteDoBrasil.create(titulo);
	
					case BANCO_ABN_AMRO_REAL:
						return AbstractCLBancoReal.create(titulo);
	
					case CAIXA_ECONOMICA_FEDERAL:
						return AbstractCLCaixaEconomicaFederal.create(titulo);
	
					case HSBC:
						return AbstractCLHSBC.create(titulo);
						
					case UNIBANCO:
						return AbstractCLUnibanco.create(titulo);
	
					case BANCO_ITAU:
						return AbstractCLItau.create(titulo);
	
					case BANCO_SAFRA:
						return AbstractCLBancoSafra.create(titulo);
	
					case BANCO_DO_ESTADO_DO_RIO_GRANDE_DO_SUL:
						return AbstractCLBanrisul.create(titulo);
						
					case MERCANTIL_DO_BRASIL:
						return AbstractCLMercantilDoBrasil.create(titulo);
						
					case NOSSA_CAIXA:
						return AbstractCLNossaCaixa.create(titulo);
					
					case BANCO_DO_ESTADO_DO_ESPIRITO_SANTO:
						return AbstractCLBanestes.create(titulo);
						
					case BANCO_RURAL:
						return AbstractCLBancoRural.create(titulo);
						
					case BANCO_SANTANDER:
						return AbstractCLSantander.create(titulo);
						
					case BANCO_INTEMEDIUM:
						return AbstractCLBancoIntermedium.create(titulo);
						
					case BANCO_fiapI:
						return AbstractCLfiapi.create(titulo);
						
					default:
						 
						throw new NotSupportedCampoLivreException(
								"Não há implementações de campo livre para o banco "
										+ titulo.getContaBancaria().getBanco()
												.getCodigoDeCompensacaoBACEN().getCodigoFormatado()
										+ " compatíveis com as "
										+ "caracteríticas do título informado.");
				}
			} else {
				
				 
				throw new NotSupportedBancoException();
			}
		} catch(CampoLivreException e) {
			 
			throw e;
			
		} catch(Exception e) {
			 
			throw new CampoLivreException(e);
		}
	}
	
	 
	protected final CampoLivre build(Titulo titulo){
		
		checkValues(titulo);
		
		addFields(titulo);
		
		return this;
	}
	
	 
	protected abstract void checkValues(Titulo titulo);
	
	 
	protected abstract void addFields(Titulo titulo);
	
	 
	protected final String writeFields() {

		StringBuilder campoLivreAtual = new StringBuilder();
		
		for(Field<?> f : this){
			campoLivreAtual.append(f.write());
		}
		
		return campoLivreAtual.toString();
	}

	 
	
	 
	private static void checkTituloNotNull(Titulo titulo){
		
		Objects.checkNotNull(titulo, "Título não pode ser nulo!");
	}
	
	 
	private static void checkContaBancariaNotNull(Titulo titulo) {
		
		Objects.checkNotNull(titulo.getContaBancaria(), "Conta bancária do título não pode ser nula!");
	}
	
	 
	private static void checkBancoNotNull(Titulo titulo) {
		
		Objects.checkNotNull(titulo.getContaBancaria().getBanco(), "Banco da conta bancária do título não pode ser nulo!");
		
		if(!isCodigoDeCompensacaoOK(titulo.getContaBancaria().getBanco().getCodigoDeCompensacaoBACEN().getCodigoFormatado())){
			
			throw new IllegalArgumentException(String.format("Código de compensação [%s] inválido!", titulo.getContaBancaria().getBanco().getCodigoDeCompensacaoBACEN().getCodigoFormatado()));
		}
	}

	 
	
	 
	protected final static void checkCarteiraNotNull(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getCarteira(), "Carteira da conta bancária do título não pode ser nula!");
	}
	
	 
	protected final static void checkRegistroDaCarteiraNotNull(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getCarteira().getTipoCobranca(), "Tipo de cobrança (COM ou SEM registro) da carteira não pode ser nulo!");
	}
	
	 
	protected final static void checkCodigoDaCarteira(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getCarteira().getCodigo(), "Código da carteira não pode ser nulo!");
		
		if(titulo.getContaBancaria().getCarteira().getCodigo() < 1){
			
			throw new IllegalArgumentException(format("Código da carteira deve ser um número inteiro natural positivo e não [%s].",titulo.getContaBancaria().getCarteira().getCodigo()));
		}
	}
	
	 
	protected final static void checkCodigoDaCarteiraMenorOuIgualQue(Titulo titulo, int limite){
		
		if(titulo.getContaBancaria().getCarteira().getCodigo() > limite){
			
			throw new IllegalArgumentException(format("Código [%s] da carteira deve ser um número menor que ou igual a [%s].", titulo.getContaBancaria().getCarteira().getCodigo()-1, limite));
		}
	}
	
	 
	protected final static void checkAgenciaNotNull(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getAgencia(), "Agência bancária do título não pode ser nula!");
	}
	
	 
	protected final static void checkCodigoDaAgencia(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getAgencia().getCodigo(), "Código da agência bancária não pode ser nulo!");
		
		if(titulo.getContaBancaria().getAgencia().getCodigo() < 1){
			
			throw new IllegalArgumentException(format("Código da agência bancária deve ser um número inteiro natural positivo e não [%s].",titulo.getContaBancaria().getAgencia().getCodigo()));
		}
	}

	 
	protected final static void checkCodigoDaAgenciaMenorOuIgualQue(Titulo titulo, int limite){
		
		if(titulo.getContaBancaria().getAgencia().getCodigo() > limite){
			
			throw new IllegalArgumentException(format("Código [%s] da agência deve ser um número menor que ou igual a [%s].", titulo.getContaBancaria().getAgencia().getCodigo()-1, limite));
		}
	}
	
	 
	protected final static void checkDigitoDoCodigoDaAgencia(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getAgencia().getDigitoVerificador(), "Dígito verificador da agência bancária não pode ser nulo!");
		Strings.checkNotBlank(titulo.getContaBancaria().getAgencia().getDigitoVerificador(), format("Dígito verificador [\"%s\"] da agência bancária não pode ser vazio!",titulo.getContaBancaria().getAgencia().getDigitoVerificador()));
		Strings.checkNotNumeric(titulo.getContaBancaria().getAgencia().getDigitoVerificador(), format("Nesse contexto o dígito verificador [\"%s\"] da agência bancária deve ser numérico!", titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta()));
	}
	
	 
	protected final static void checkNumeroDaContaNotNull(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getNumeroDaConta(), "Número da conta bancária do título não pode ser nulo!");
	}
	
	 
	protected final static void checkCodigoDoNumeroDaConta(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), "Código do número da conta bancária não pode ser nulo!");
		
		if(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta() < 1){
			
			throw new IllegalArgumentException(format("Código do número da conta bancária deve ser um número inteiro natural positivo e não [%s].",titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta()));
		}
	}
	
	 
	protected final static void checkCodigoDoNumeroDaContaMenorOuIgualQue(Titulo titulo, int limite){
		
		if(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta() > limite){
			
			throw new IllegalArgumentException(format("Código [%s] do número da conta deve ser um número menor que ou igual a [%s].", titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), limite));
		}
	}
	
	 
	protected final static void checkDigitoDoCodigoDoNumeroDaConta(Titulo titulo){
		
		Objects.checkNotNull(titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta(), "Dígito verificador do número da conta bancária não pode ser nulo!");
		Strings.checkNotBlank(titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta(), format("Dígito verificador [\"%s\"] do número da conta bancária não pode ser vazio!", titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta()));
		Strings.checkNotNumeric(titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta(), format("Nesse contexto o dígito verificador [\"%s\"] do número da conta deve ser numérico!", titulo.getContaBancaria().getNumeroDaConta().getDigitoDaConta()));
	}
	
	 
	protected final static void checkNossoNumero(Titulo titulo){
		
		Objects.checkNotNull(titulo.getNossoNumero(), "Nosso número do título não pode ser nulo!");
		Strings.checkNotBlank(titulo.getNossoNumero(), format("Nosso número [\"%s\"] do título não pode ser vazio!", titulo.getNossoNumero()));
		Strings.checkNotNumeric(titulo.getNossoNumero(), format("Nosso número [\"%s\"] do título deve conter somente dígitos numéricos!", titulo.getNossoNumero()));
	}
	
	 
	protected final static void checkTamanhoDoNossoNumero(Titulo titulo, int length) {

		checkTamanhoNossoNumero(titulo, length, format(
				"Tamanho [%s] do nosso número [\"%s\"] diferente do esperado [%s]!",
				StringUtils.length(titulo.getNossoNumero()), titulo.getNossoNumero(), length));
	}
	
	 
	protected final static void checkTamanhoNossoNumero(Titulo titulo, int length, String msg){
		
		if(titulo.getNossoNumero().length() != length){
			
			throw new IllegalArgumentException(msg);
		}
	}
	
	 
	protected final static void checkDigitoDoNossoNumero(Titulo titulo){
		
		Objects.checkNotNull(titulo.getDigitoDoNossoNumero(), "Dígito verificador do nosso número do título não pode ser nulo!");
		Strings.checkNotBlank(titulo.getDigitoDoNossoNumero(), format("Dígito verificador [\"%s\"] do nosso número do título não pode ser vazio!", titulo.getDigitoDoNossoNumero()));
		Strings.checkNotNumeric(titulo.getNossoNumero(), format("Nesse contexto o dígito verificador [\"%s\"] do nosso número deve ser numérico!", titulo.getDigitoDoNossoNumero()));
	}
	
	 
	protected final static void checkTamanhoDigitoDoNossoNumero(Titulo titulo, int length) {

		checkTamanhoDigitoDoNossoNumero(titulo, length, format(
				"Tamanho [%s] do dígito do nosso número [\"%s\"] diferente do esperado [%s]!",
				StringUtils.length(titulo.getDigitoDoNossoNumero()), titulo.getDigitoDoNossoNumero(), length));
	}
	
	 
	protected final static void checkTamanhoDigitoDoNossoNumero(Titulo titulo, int length, String msg){
		
		if(titulo.getDigitoDoNossoNumero().length() != length){
			
			throw new IllegalArgumentException(msg);
		}
	}
	
	 
	protected final static void checkValor(Titulo titulo){
		
		Objects.checkNotNull(titulo.getValor(), "Valor do título não pode ser nulo!");
		
		if(titulo.getValor().compareTo(ZERO) == -1){
			
			throw new IllegalArgumentException(format("O valro do título deve ser um número positivo ou zero e não [%s].",titulo.getValor()));
		}
	}
	
	 
	protected final static void checkParametrosBancarios(Titulo titulo, String param){
		
		Objects.checkNotNull(titulo.getParametrosBancarios(), format("O parâmetro bancário [\"%s\"] é necessário! [titulo.getParametrosBancarios() == null]",param));
		
		if(titulo.getParametrosBancarios().contemComNome(param)){
			
			Objects.checkNotNull(titulo.getParametrosBancarios().getValor(param), format("Parâmetro bancário [\"%s\"] não contém valor!", param));
		
		}else{
				
			throw new IllegalArgumentException(format("Parâmetro bancário [\"%s\"] não encontrado!",param));
		}
	}
	
	 
	@Override
	public String toString() {
		
		return Objects.toString(this);
	}
	
}
