 

package br.com.fiap.framework.campolivre;

import static org.apache.commons.lang.StringUtils.EMPTY;
import static org.apache.commons.lang.StringUtils.isNumeric;
import static org.apache.commons.lang.StringUtils.remove;
import static org.apache.commons.lang.StringUtils.strip;

import org.apache.log4j.Logger;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.Objects;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.utilix.text.Strings;


 
public final class CampoLivreFactory {

	 
	private static final long serialVersionUID = 8572635342980404937L;
	
	private static Logger log = Logger.getLogger(CampoLivreFactory.class);

	 
	public static CampoLivre create(Titulo titulo) throws NotSupportedBancoException, NotSupportedCampoLivreException {

		return AbstractCampoLivre.create(titulo);
	}
	
	 
	public static CampoLivre create(String strCampoLivre) {
		
		CampoLivre campoLivre = null;
		
		Objects.checkNotNull(strCampoLivre);
		
		Strings.checkNotBlank(strCampoLivre, "O Campo Livre não deve ser vazio!");
		
		strCampoLivre = strip(strCampoLivre); 
		
		if (strCampoLivre.length() == CampoLivre.STRING_LENGTH) {

			if (remove(strCampoLivre, ' ').length() == CampoLivre.STRING_LENGTH) {

				if (isNumeric(strCampoLivre)) {

					campoLivre = new CampoLivre() {

						private static final long serialVersionUID = -7592488081807235080L;

						Field<String> campo = new Field<String>(EMPTY,
								STRING_LENGTH, Filler.ZERO_LEFT);

						
						public void read(String str) {
							campo.read(str);
						}

						
						public String write() {
							return campo.write();
						}
					};
					
					campoLivre.read(strCampoLivre);
					
				} else {
					
					IllegalArgumentException e = new IllegalArgumentException("O Campo Livre [ " + strCampoLivre + " ] deve ser uma String numérica!");
					
					log.error(EMPTY, e);
					
					throw e;
				}
			} else {
				
				IllegalArgumentException e = new IllegalArgumentException("O Campo Livre [ " + strCampoLivre + " ] não deve conter espaços em branco!");
				
				log.error(EMPTY, e);
				
				throw e;
			}
		} else {
			
			IllegalArgumentException e = new IllegalArgumentException("O tamanho do Campo Livre [ " + strCampoLivre + " ] deve ser igual a 25 e não ["+strCampoLivre.length()+"]!");
			
			log.error(EMPTY, e);
			
			throw e;
		}
			
		return campoLivre;
	}

	 
	@Override
	public String toString() {
		return Objects.toString(this);
	}
}
