 

package br.com.fiap.framework.view;

import static org.apache.commons.lang.StringUtils.EMPTY;
import static org.27scj-framework-jasper.utilix.Objects.isNotNull;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.27scj-framework-jasper.utilix.Collections;
import org.27scj-framework-jasper.utilix.Objects;

import br.com.fiap.framework.Boleto;

 
public class BoletoViewer {

	 
	private static Logger log = Logger.getLogger(BoletoViewer.class);

	 
	private PdfViewer pdfViewer;

	 
	public BoletoViewer(Boleto boleto) {

		Objects.checkNotNull(boleto);

		this.pdfViewer = new PdfViewer(boleto);
	}

	 
	public BoletoViewer(Boleto boleto, String templatePath) {

		Objects.checkNotNull(boleto);

		setTemplate(templatePath);

		this.pdfViewer = new PdfViewer(boleto);
	}

	 
	public BoletoViewer(Boleto boleto, File templateFile) {

		Objects.checkNotNull(boleto);

		this.pdfViewer = new PdfViewer(boleto);
		
		setTemplate(templateFile);
	}

	 
	BoletoViewer() {

		this.pdfViewer = new PdfViewer();
	}

	 
	public static File groupInOnePDF(List<Boleto> boletos, String destPath) {

		checkBoletosList(boletos);
		checkDestPath(destPath);

		return PdfViewer.groupInOnePDF(boletos, new File(destPath),
				new BoletoViewer());
	}

	 
	public static File groupInOnePDF(List<Boleto> boletos, File destFile) {

		checkBoletosList(boletos);
		checkDestFile(destFile);

		return PdfViewer.groupInOnePDF(boletos, destFile, new BoletoViewer());
	}

	 
	public static File groupInOnePDF(List<Boleto> boletos, String destPath,
			String templatePath) {

		checkBoletosList(boletos);
		checkDestPath(destPath);
		checkTemplatePath(templatePath);

		return PdfViewer.groupInOnePDF(boletos, new File(destPath),
				new BoletoViewer().setTemplate(templatePath));
	}

	 
	public static File groupInOnePDF(List<Boleto> boletos, String destPath,
			File templateFile) {

		checkBoletosList(boletos);
		checkDestPath(destPath);
		checkTemplateFile(templateFile);

		return PdfViewer.groupInOnePDF(boletos, new File(destPath),
				new BoletoViewer().setTemplate(templateFile));
	}

	 
	public static File groupInOnePDF(List<Boleto> boletos, File destFile,
			String templatePath) {

		checkBoletosList(boletos);
		checkDestFile(destFile);
		checkTemplatePath(templatePath);

		return PdfViewer.groupInOnePDF(boletos, destFile, new BoletoViewer()
				.setTemplate(templatePath));
	}

	 
	public static File groupInOnePDF(List<Boleto> boletos, File destFile,
			File templateFile) {

		checkBoletosList(boletos);
		checkDestFile(destFile);
		checkTemplateFile(templateFile);

		return PdfViewer.groupInOnePDF(boletos, destFile, new BoletoViewer()
				.setTemplate(templateFile));
	}

	 
	public static List<File> onePerPDF(List<Boleto> boletos, String destPath) {

		checkBoletosList(boletos);
		checkDestPath(destPath);

		return onePerPDF(boletos, new File(destPath), EMPTY, EMPTY);
	}

	 
	public static List<File> onePerPDF(List<Boleto> boletos, File destDir) {

		checkBoletosList(boletos);
		checkDestDir(destDir);

		return onePerPDF(boletos, destDir, EMPTY, EMPTY);
	}

	 
	public static List<File> onePerPDF(List<Boleto> boletos, String destPath,
			String prefixo) {

		checkBoletosList(boletos);
		checkDestPath(destPath);

		return onePerPDF(boletos, new File(destPath), prefixo, EMPTY);
	}

	 
	public static List<File> onePerPDF(List<Boleto> boletos, File destDir,
			String prefixo) {

		checkBoletosList(boletos);
		checkDestDir(destDir);

		return onePerPDF(boletos, destDir, prefixo, EMPTY);
	}

	 
	public static List<File> onePerPDF(List<Boleto> boletos, String destPath,
			String prefixo, String sufixo) {

		checkBoletosList(boletos);
		checkDestPath(destPath);

		return onePerPDF(boletos, new File(destPath), prefixo, sufixo);
	}

	 
	public static List<File> onePerPDF(List<Boleto> boletos, File destDir,
			String prefixo, String sufixo) {

		checkBoletosList(boletos);
		checkDestDir(destDir);

		List<File> files = new ArrayList<File>(boletos.size());

		files.addAll(PdfViewer.onePerPDF(boletos, destDir, prefixo, sufixo));

		return files;
	}

	 
	public File getTemplate() {

		return pdfViewer.getTemplate();
	}

	 
	public BoletoViewer setTemplate(File template) {

		checkTemplateFile(template);

		this.pdfViewer.setTemplate(template);

		return this;
	}

	 
	public BoletoViewer setTemplate(String pathName) {

		checkTemplatePath(pathName);

		this.pdfViewer.setTemplate(pathName);

		return this;
	}

	 
	public BoletoViewer removeTemplate() {

		final String DEFAULT = null;

		if (isNotNull(pdfViewer)) {
			pdfViewer.setTemplate(DEFAULT);
		}

		return this;
	}

	 
	public File getPdfAsFile(String destPath) {

		if (log.isDebugEnabled()) {
			log.debug("documento instance : " + pdfViewer);
		}

		return pdfViewer.getFile(destPath);
	}

	 
	public File getPdfAsFile(File destFile) {

		if (log.isDebugEnabled()) {
			log.debug("documento instance : " + pdfViewer);
		}

		return pdfViewer.getFile(destFile);
	}

	 
	public ByteArrayOutputStream getPdfAsStream() {

		if (log.isDebugEnabled()) {
			log.debug("documento instance : " + pdfViewer);
		}

		return pdfViewer.getStream();

	}

	 
	public byte[] getPdfAsByteArray() {

		if (log.isDebugEnabled()) {
			log.debug("documento instance : " + pdfViewer);
		}

		return pdfViewer.getBytes();
	}

	 
	public Boleto getBoleto() {

		return pdfViewer.getBoleto();
	}

	 
	public BoletoViewer setBoleto(Boleto boleto) {

		Objects.checkNotNull(boleto);

		updateViewerPDF(boleto);

		return this;
	}

	 
	private void updateViewerPDF(Boleto boleto) {

		if (isNotNull(this.pdfViewer)) {

			this.pdfViewer = new PdfViewer(boleto, this.pdfViewer.getTemplate());

		} else {

			this.pdfViewer = new PdfViewer(boleto);
		}
	}

	private static void checkDestPath(String path) {

		checkString(path,
				"Caminho destinado a geração do(s) arquivo(s) não contém informação!");
	}

	private static void checkTemplatePath(String path) {

		checkString(path, "Caminho do template não contém informação!");
	}

	private static void checkString(String str, String msg) {

		Objects.checkNotNull(str);

		if (StringUtils.isBlank(str)) {

			throw new IllegalArgumentException(msg);
		}
	}

	private static void checkDestDir(File file) {

		Objects.checkNotNull(file,
				"Diretório destinado a geração do(s) boleto(s) nulo!");

		if (!file.isDirectory()) {

			throw new IllegalArgumentException(
					"Isto não é um diretório válido!");
		}
	}

	private static void checkDestFile(File file) {

		Objects.checkNotNull(file,
				"Arquivo destinado a geração do(s) boleto(s) nulo!");
	}

	private static void checkTemplateFile(File file) {

		Objects.checkNotNull(file, "Arquivo de template nulo!");
	}

	private static void checkBoletosList(List<Boleto> boletos) {

		Objects.checkNotNull(boletos, "Lista de boletos nula!");
		Collections.checkNotEmpty(boletos, "A Lista de boletos está vazia!");
	}
}
