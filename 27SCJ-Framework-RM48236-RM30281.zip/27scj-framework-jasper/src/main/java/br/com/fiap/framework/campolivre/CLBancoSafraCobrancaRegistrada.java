 

package br.com.fiap.framework.campolivre;

import static org.27scj-framework-jasper.utilix.Objects.exists;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBancoSafraCobrancaRegistrada extends AbstractCLBancoSafra {

	 
	private static final long serialVersionUID = -4532989921797507161L;

	private static final int TIPO_COBRANCA = 2;
	
	 
	CLBancoSafraCobrancaRegistrada(Titulo titulo) {
		super(FIELDS_LENGTH);
		
		ContaBancaria conta = titulo.getContaBancaria();
		
		if(exists(conta.getAgencia().getDigitoVerificador())) {
			
			this.add(new Field<Integer>(SISTEMA, 1));
			
			this.add(new Field<String>(
					Filler.ZERO_LEFT.fill(conta.getAgencia().getCodigo(), 4) + 
					conta.getAgencia().getDigitoVerificador() +
					Filler.ZERO_LEFT.fill(conta.getNumeroDaConta().getCodigoDaConta(), 8) +
					conta.getNumeroDaConta().getDigitoDaConta(), 14));
			
			this.add(new Field<String>(titulo.getNossoNumero(), 9, Filler.ZERO_LEFT));
			this.add(new Field<Integer>(TIPO_COBRANCA, 1));
			
		}
		else {
			throw new CampoLivreException(new IllegalArgumentException(
			"Defina o dígito verificador da agência da conta bancária."));
		}
		
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
