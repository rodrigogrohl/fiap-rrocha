 

package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLfiapi extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = -55594606026629224L;

	 
	protected AbstractCLfiapi(Integer fieldsLength) {

		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) {

		return new CLfiapi().build(titulo);
	}
}
