 

package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLItauComCarteirasEspeciais extends AbstractCLItau {

	 
	private static final long serialVersionUID = -1532454262023154419L;
	
	 
	private static final Integer FIELDS_LENGTH = 6;
	
	 
	public CLItauComCarteirasEspeciais(Titulo titulo) {
		super(FIELDS_LENGTH);
		
		ContaBancaria conta = titulo.getContaBancaria();
		
		this.add(new Field<Integer>(conta.getCarteira().getCodigo(), 3, Filler.ZERO_LEFT));
		this.add(new Field<String>(titulo.getNossoNumero(), 8, Filler.ZERO_LEFT));
		this.add(new Field<String>(titulo.getNumeroDoDocumento(), 7, Filler.ZERO_LEFT));
		
		//Aqui é o código do cedente, simbolizado pelo código da conta bancária.
		this.add(new Field<Integer>(conta.getNumeroDaConta().getCodigoDaConta(), 5, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(calculeDigitoDoCampoLivreEspecial(
											conta.getCarteira().getCodigo(), 
											titulo.getNossoNumero(),
											titulo.getNumeroDoDocumento(),
											conta.getNumeroDaConta().getCodigoDaConta()), 1));
		this.add(new Field<Integer>(0, 1));
	}
	
	 
	private Integer calculeDigitoDoCampoLivreEspecial(Integer codigoDaCarteira,
			String nossoNumero, String numeroDoDocumento, Integer codigoDaConta) {

		StringBuilder campo = new StringBuilder();
		
		campo.append(Filler.ZERO_LEFT.fill(codigoDaCarteira.intValue(), 3));
		campo.append(Filler.ZERO_LEFT.fill(nossoNumero, 8));
		campo.append(Filler.ZERO_LEFT.fill(numeroDoDocumento, 7));
		campo.append(Filler.ZERO_LEFT.fill(codigoDaConta, 5));
		
		return calculeDigitoVerificador(campo.toString());
	}

	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
