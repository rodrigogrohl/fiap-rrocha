 
	
package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLBancoSafraCobrancaNaoRegistrada extends AbstractCLBancoSafra {

	 
	private static final long serialVersionUID = -6573340701469029151L;
	
	private static final int TIPO_COBRANCA = 4;

	 
	CLBancoSafraCobrancaNaoRegistrada(Titulo titulo) {
		super(FIELDS_LENGTH);
		
		ContaBancaria conta = titulo.getContaBancaria();
		
		this.add(new Field<Integer>(SISTEMA, 1));
		
		//Referente a identificação do cliente.
		this.add(new Field<String>(
				Filler.ZERO_LEFT.fill(conta.getNumeroDaConta().getCodigoDaConta(), 5) +
				conta.getNumeroDaConta().getDigitoDaConta(), 6));
		
		this.add(new Field<String>(titulo.getNossoNumero(), 17, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(TIPO_COBRANCA, 1));
		
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
