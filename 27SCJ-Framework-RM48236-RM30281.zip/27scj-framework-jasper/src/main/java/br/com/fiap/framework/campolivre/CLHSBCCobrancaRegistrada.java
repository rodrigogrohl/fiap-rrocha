 

package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLHSBCCobrancaRegistrada extends AbstractCLHSBC{

	 
	private static final long serialVersionUID = -5052841093486791338L;
	
	private static final Integer FIELDS_LENGTH = 6;

	private static final String CODIGO_DA_CARTEIRA = "00";

	private static final Integer CODIGO_DO_APLICATIVO = Integer.valueOf(1);

	 
	CLHSBCCobrancaRegistrada(Titulo titulo) {
		
		super(FIELDS_LENGTH);
		
		this.add(new Field<String>(titulo.getNossoNumero(), 10, Filler.ZERO_LEFT));	
		this.add(new Field<String>(titulo.getDigitoDoNossoNumero(), 1));	
		this.add(new Field<Integer>(titulo.getContaBancaria().getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(titulo.getContaBancaria().getNumeroDaConta().getCodigoDaConta(), 7, Filler.ZERO_LEFT));
		this.add(new Field<String>(CODIGO_DA_CARTEIRA, 2));
		this.add(new Field<Integer>(CODIGO_DO_APLICATIVO, 1));
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}
