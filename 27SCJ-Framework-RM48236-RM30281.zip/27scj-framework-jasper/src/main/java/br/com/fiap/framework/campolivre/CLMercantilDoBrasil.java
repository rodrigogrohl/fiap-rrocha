 
package br.com.fiap.framework.campolivre;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;

 
class CLMercantilDoBrasil extends AbstractCLMercantilDoBrasil {

	 
	private static final long serialVersionUID = 2335934898236961987L;
	
	 
	private static final Integer FIELDS_LENGTH = 4;

	 
	CLMercantilDoBrasil(Titulo titulo) {
		super(FIELDS_LENGTH);
		
		ContaBancaria contaBancaria = titulo.getContaBancaria();
		
//		int digitoDoNossoNumero = calculeDigitoVerificadorDoNossoNumero(contaBancaria.getAgencia().getCodigoDaAgencia(), nossoNumero);
		
		//TODO Verificar de onde virá esta informação: apenas verificar se o título tem ou não valor de desconto.
		int desconto;
		if(titulo.getDesconto() == null || titulo.getDesconto().equals(BigDecimal.ZERO.setScale(2, RoundingMode.DOWN))) {
			desconto = 2;
			
		} else {
			desconto = 0;
		}
		
		this.add(new Field<Integer>(contaBancaria.getAgencia().getCodigo(), 4, Filler.ZERO_LEFT));
		
		this.add(new Field<String>(titulo.getNossoNumero() + titulo.getDigitoDoNossoNumero(), 11, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(contaBancaria.getNumeroDaConta().getCodigoDaConta(), 9, Filler.ZERO_LEFT));
		
		this.add(new Field<Integer>(desconto, 1));
	}
	
	 
//	private int calculeDigitoVerificadorDoNossoNumero(Integer agencia, String nossoNumero) {
//		
//		Modulo modulo = new Modulo(EnumModulo.MODULO11);
//		int resto = modulo.calcule(Filler.ZERO_LEFT.fill(agencia, 4) + nossoNumero);
//		
//		int digito = modulo.valor() - resto;
//		
//		return digito;
//	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

}
