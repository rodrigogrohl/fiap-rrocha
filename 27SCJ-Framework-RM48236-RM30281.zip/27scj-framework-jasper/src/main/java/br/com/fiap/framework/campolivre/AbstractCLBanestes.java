 
package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBanestes extends AbstractCampoLivre {
	
	 
	private static final long serialVersionUID = 2713363808443832056L;

	 
	protected AbstractCLBanestes(Integer fieldsLength) {
		
		super(fieldsLength);
	}
	
	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException {
		
		return new CLBanestes(titulo);
	}
}
