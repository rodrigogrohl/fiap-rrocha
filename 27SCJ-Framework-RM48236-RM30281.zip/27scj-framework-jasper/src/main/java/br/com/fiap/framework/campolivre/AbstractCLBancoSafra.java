 

package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLBancoSafra extends AbstractCampoLivre {
	
	 
	private static final long serialVersionUID = -555393808447532987L;

	 
	protected static final Integer FIELDS_LENGTH = 4;
	
	protected static final int SISTEMA = 7;

	 
	protected AbstractCLBancoSafra(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	protected static CampoLivre create(Titulo titulo) throws NotSupportedCampoLivreException {

		checkCarteiraNotNull(titulo);
		checkRegistroDaCarteiraNotNull(titulo);
		
		switch(titulo.getContaBancaria().getCarteira().getTipoCobranca()){
		case COM_REGISTRO:
			return new CLBancoSafraCobrancaRegistrada(titulo);
		case SEM_REGISTRO:
			return new CLBancoSafraCobrancaNaoRegistrada(titulo);
		default:
			return null;
		}
	}
}
