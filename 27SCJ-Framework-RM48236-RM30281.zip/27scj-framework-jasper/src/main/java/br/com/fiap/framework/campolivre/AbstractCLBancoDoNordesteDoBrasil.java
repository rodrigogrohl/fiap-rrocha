 
package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
public abstract class AbstractCLBancoDoNordesteDoBrasil extends AbstractCampoLivre {


	 
	private static final long serialVersionUID = -5036970456320987443L;

	 
	protected AbstractCLBancoDoNordesteDoBrasil(Integer fieldsLength) {
		super(fieldsLength);
		// TODO Auto-generated constructor stub
	}
	
	 
	protected static CampoLivre create(Titulo titulo){
		return new CLBancoDoNordesteDoBrasil().build(titulo);
	}	
	

}
