 
	
package br.com.fiap.framework.campolivre;

 
public class CampoLivreException extends RuntimeException {

	 
	private static final long serialVersionUID = 893327780214327141L;

	 
	public CampoLivreException() {
		super();
	}

	 
	public CampoLivreException(String message, Throwable cause) {
		super(message, cause);
	}

	 
	public CampoLivreException(String message) {
		super(message);
	}

	 
	public CampoLivreException(Throwable cause) {
		super(cause);
	}

}
