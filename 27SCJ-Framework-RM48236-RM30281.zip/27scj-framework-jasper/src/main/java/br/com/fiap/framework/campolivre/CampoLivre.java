 


package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.utilix.text.TextStream;

 
public interface CampoLivre extends TextStream{
	
	 
	Integer STRING_LENGTH = 25;
}
