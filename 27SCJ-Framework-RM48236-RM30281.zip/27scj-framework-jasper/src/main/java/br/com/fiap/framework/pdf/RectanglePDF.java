 

package br.com.fiap.framework.pdf;

import com.lowagie.text.Rectangle;

 
public class RectanglePDF extends Rectangle {

	private int page;

	 
	public RectanglePDF(float[] positions) {
		super(positions[1], positions[2], positions[3], positions[4]);
		page = (int) positions[0];
	}

	 
	public RectanglePDF(float llx, float lly, float urx, float ury) {
		super(llx, lly, urx, ury);
	}

	 
	public RectanglePDF(float urx, float ury) {
		super(urx, ury);
	}

	 
	public RectanglePDF(Rectangle rect) {
		super(rect);
	}

	 
	public int getPage() {
		return page;
	}

	 
	public float getLowerLeftX() {
		return this.llx;
	}

	 
	public float getLowerLeftY() {
		return lly;
	}

	 
	public float getUpperRightX() {
		return urx;
	}

	 
	public float getUpperRightY() {
		return ury;
	}
}
