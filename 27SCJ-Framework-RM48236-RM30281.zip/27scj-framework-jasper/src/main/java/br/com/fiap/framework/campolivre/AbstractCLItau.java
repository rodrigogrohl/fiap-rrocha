
 
	
package br.com.fiap.framework.campolivre;
import static org.27scj-framework-jasper.vallia.digitoverificador.Modulo.MOD10;

import java.util.HashSet;
import java.util.Set;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;

 
abstract class AbstractCLItau extends AbstractCampoLivre {
	
	 
	private static final long serialVersionUID = -3082903872777434482L;
	
	 
	private static final Set<Integer> CARTEIRAS_ESPECIAIS = new HashSet<Integer>(8);
	
	static{
		
		CARTEIRAS_ESPECIAIS.add(106);
		CARTEIRAS_ESPECIAIS.add(107);
		CARTEIRAS_ESPECIAIS.add(122);
		CARTEIRAS_ESPECIAIS.add(142);
		CARTEIRAS_ESPECIAIS.add(143);
		CARTEIRAS_ESPECIAIS.add(195);
		CARTEIRAS_ESPECIAIS.add(196);
		CARTEIRAS_ESPECIAIS.add(198);
	}

	 
	protected AbstractCLItau(Integer fieldsLength) {
		
		super(fieldsLength);
	}
	
	 
	protected static CampoLivre create(Titulo titulo){
		
		checkCarteiraNotNull(titulo);
		checkCodigoDaCarteira(titulo);
		
		 
		if(CARTEIRAS_ESPECIAIS.contains(titulo.getContaBancaria().getCarteira().getCodigo())) {
			
			return new CLItauComCarteirasEspeciais(titulo);
			
		}else {
			
			return new CLItauPadrao(titulo);
		}
	}
	
	 
	protected Integer calculeDigitoVerificador(String campo) {
				
		int restoDivisao = Modulo.calculeMod10(campo, 1, 2);
		int digito = MOD10 - restoDivisao;
		
		if(digito > 9) {
			digito = 0;
		}
		
		return new Integer(digito);
	}

}
