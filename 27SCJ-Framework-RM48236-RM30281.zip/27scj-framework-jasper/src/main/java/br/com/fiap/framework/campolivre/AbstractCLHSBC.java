 

package br.com.fiap.framework.campolivre;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;

 
abstract class AbstractCLHSBC extends AbstractCampoLivre {

	 
	private static final long serialVersionUID = 3179450500491723317L;

	 
	protected AbstractCLHSBC(Integer fieldsLength) {
		
		super(fieldsLength);
	}

	 
	 protected static CampoLivre create(Titulo titulo) {
		
		checkCarteiraNotNull(titulo);
		checkRegistroDaCarteiraNotNull(titulo);

		switch(titulo.getContaBancaria().getCarteira().getTipoCobranca()){
		case SEM_REGISTRO:
			return new CLHSBCCobrancaNaoRegistrada(titulo);
		case COM_REGISTRO:
			return new CLHSBCCobrancaRegistrada(titulo);
		default:
			return null;
		}
	}
}
