 

package br.com.fiap.framework.campolivre;
import static org.27scj-framework-jasper.vallia.digitoverificador.Modulo.MOD11;

import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.ContaBancaria;
import org.27scj-framework-jasper.domkee.financeiro.banco.febraban.Titulo;
import org.27scj-framework-jasper.utilix.text.Field;
import org.27scj-framework-jasper.utilix.text.Filler;
import org.27scj-framework-jasper.vallia.digitoverificador.Modulo;

 
class CLCaixaEconomicaFederalSIGCB extends AbstractCLCaixaEconomicaFederal {

	 
	private static final long serialVersionUID = -7642075752245778160L;

	 
	private static final Integer FIELDS_LENGTH = 8;

	 
	private static final int COBRANCA_REGISTRADA = 1;
	
	 
	private static final int COBRANCA_NAO_REGISTRADA = 2;
	
	 
	private static final int EMISSAO_CEDENTE = 4;

	 
	CLCaixaEconomicaFederalSIGCB(Titulo titulo) {
		
		super(FIELDS_LENGTH);

		ContaBancaria conta = titulo.getContaBancaria();
		String nossoNumero = titulo.getNossoNumero();

		Integer dVCodigoDoCedente = calculeDigitoVerificador(conta.getNumeroDaConta().getCodigoDaConta().toString());

		this.add(new Field<Integer>(conta.getNumeroDaConta().getCodigoDaConta(), 6, Filler.ZERO_LEFT));
		this.add(new Field<Integer>(dVCodigoDoCedente, 1));
		this.add(new Field<String>(nossoNumero.substring(0, 3), 3));
		
		if(conta.getCarteira().isComRegistro()){
			
			this.add(new Field<Integer>(COBRANCA_REGISTRADA, 1));
			
		}else{
			
			this.add(new Field<Integer>(COBRANCA_NAO_REGISTRADA, 1));
		}

		this.add(new Field<String>(nossoNumero.substring(3, 6), 3));
		this.add(new Field<Integer>(EMISSAO_CEDENTE, 1));
		this.add(new Field<String>(nossoNumero.substring(6, 15), 9));

		this.add(new Field<Integer>(calculeDigitoVerificador(gereCampoLivre()), 1));
	}

	 
	private String gereCampoLivre() {

		return writeFields();
	}

	 
	private int calculeDigitoVerificador(String numeroParaCalculo) {
		
		int soma = Modulo.calculeSomaSequencialMod11(numeroParaCalculo.toString(), 2, 9);

		int dvCampoLivre;
		
		if (soma < MOD11) {
			
			dvCampoLivre = MOD11 - soma;
			
		} else {
		
			int restoDiv11 = soma % MOD11;
			
			int subResto = MOD11 - restoDiv11;
			
			if (subResto > 9) {
			
				dvCampoLivre = 0;
			
			} else {
				
				dvCampoLivre = subResto;
			}
		}
		
		return dvCampoLivre;
	}
	
	@Override
	protected void addFields(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}

	@Override
	protected void checkValues(Titulo titulo) {
		// TODO IMPLEMENTAR
		throw new UnsupportedOperationException("AINDA NÃO IMPLEMENTADO!");
	}
}