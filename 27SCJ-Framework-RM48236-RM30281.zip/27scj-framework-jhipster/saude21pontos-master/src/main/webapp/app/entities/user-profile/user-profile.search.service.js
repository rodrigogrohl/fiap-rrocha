(function() {
    'use strict';

    angular
        .module('saude21PontosApp')
        .factory('UserProfileSearch', UserProfileSearch);

    UserProfileSearch.$inject = ['$resource'];

    function UserProfileSearch($resource) {
        var resourceUrl =  'api/_search/user-profiles/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
