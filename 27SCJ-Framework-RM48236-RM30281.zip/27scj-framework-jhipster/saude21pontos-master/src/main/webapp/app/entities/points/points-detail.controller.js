(function() {
    'use strict';

    angular
        .module('saude21PontosApp')
        .controller('PointsDetailController', PointsDetailController);

    PointsDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Points', 'User'];

    function PointsDetailController($scope, $rootScope, $stateParams, previousState, entity, Points, User) {
        var vm = this;

        vm.points = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('saude21PontosApp:pointsUpdate', function(event, result) {
            vm.points = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
