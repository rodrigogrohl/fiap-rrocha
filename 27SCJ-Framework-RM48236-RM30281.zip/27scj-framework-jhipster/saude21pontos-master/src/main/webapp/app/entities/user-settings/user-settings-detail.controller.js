(function() {
    'use strict';

    angular
        .module('saude21PontosApp')
        .controller('UserSettingsDetailController', UserSettingsDetailController);

    UserSettingsDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'UserSettings', 'UserProfile', 'User'];

    function UserSettingsDetailController($scope, $rootScope, $stateParams, previousState, entity, UserSettings, UserProfile, User) {
        var vm = this;

        vm.userSettings = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('saude21PontosApp:userSettingsUpdate', function(event, result) {
            vm.userSettings = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
