(function() {
    'use strict';

    angular
        .module('saude21PontosApp')
        .controller('UserSettingsDialogController', UserSettingsDialogController);

    UserSettingsDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'UserSettings', 'UserProfile', 'User'];

    function UserSettingsDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, UserSettings, UserProfile, User) {
        var vm = this;

        vm.userSettings = entity;
        vm.clear = clear;
        vm.save = save;
        vm.userprofiles = UserProfile.query({filter: 'usersettings-is-null'});
        $q.all([vm.userSettings.$promise, vm.userprofiles.$promise]).then(function() {
            if (!vm.userSettings.userProfile || !vm.userSettings.userProfile.id) {
                return $q.reject();
            }
            return UserProfile.get({id : vm.userSettings.userProfile.id}).$promise;
        }).then(function(userProfile) {
            vm.userprofiles.push(userProfile);
        });
        vm.users = User.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.userSettings.id !== null) {
                UserSettings.update(vm.userSettings, onSaveSuccess, onSaveError);
            } else {
                UserSettings.save(vm.userSettings, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('saude21PontosApp:userSettingsUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
