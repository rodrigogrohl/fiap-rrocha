(function () {
    'use strict';

    angular
        .module('saude21PontosApp')
        .controller('SocialAuthController', SocialAuthController);

    SocialAuthController.$inject = ['$state', '$cookies', 'Auth'];

    function SocialAuthController($state, $cookies, Auth) {
        var token = $cookies.get('social-authentication');

        Auth.loginWithToken(token, false).then(function () {
            $cookies.remove('social-authentication');
            Auth.authorize(true);
        }, function () {
            $state.go('social-register', {'success': 'false'});
        });
    }
})();
