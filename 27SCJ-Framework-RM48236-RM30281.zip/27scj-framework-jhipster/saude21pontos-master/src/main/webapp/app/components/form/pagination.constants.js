(function() {
    'use strict';

    angular
        .module('saude21PontosApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
