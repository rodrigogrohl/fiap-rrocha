/**
 * Swagger api specific code.
 */
package br.com.rockage.config.apidoc;