/**
 * Spring Data ElasticSearch repositories.
 */
package br.com.rockage.repository.search;
