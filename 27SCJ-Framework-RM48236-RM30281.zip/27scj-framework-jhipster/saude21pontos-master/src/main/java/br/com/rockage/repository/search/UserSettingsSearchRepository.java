package br.com.rockage.repository.search;

import br.com.rockage.domain.UserSettings;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the UserSettings entity.
 */
public interface UserSettingsSearchRepository extends ElasticsearchRepository<UserSettings, Long> {
}
