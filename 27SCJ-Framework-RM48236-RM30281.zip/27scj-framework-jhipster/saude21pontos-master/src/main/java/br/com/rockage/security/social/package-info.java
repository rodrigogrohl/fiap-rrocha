/**
 * Spring social configuration.
 */
package br.com.rockage.security.social;
