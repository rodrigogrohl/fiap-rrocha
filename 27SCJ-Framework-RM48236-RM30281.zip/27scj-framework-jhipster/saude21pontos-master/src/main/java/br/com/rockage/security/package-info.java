/**
 * Spring Security configuration.
 */
package br.com.rockage.security;
