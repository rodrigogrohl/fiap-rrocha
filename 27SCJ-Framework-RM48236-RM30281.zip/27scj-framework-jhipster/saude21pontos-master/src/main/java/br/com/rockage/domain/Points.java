package br.com.rockage.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A Points.
 */
@Entity
@Table(name = "points")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "points")
public class Points implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "date", nullable = false)
    private LocalDate date;

    @NotNull
    @Column(name = "exercise")
    private Integer exercise = 0;

    @NotNull
    @Column(name = "meals")
    private Integer meals = 0;

    @NotNull
    @Column(name = "alcohol")
    private Integer alcohol = 0;
    
    @Column(name = "notes")
    private String notes;

    @ManyToOne
    private User userProfile;

    public Points() { }
    
    public Points(LocalDate date, int exercise, int meals, int alcohol, User user) {
    	this.date = date;
    	setExercise(exercise);
		setMeals(meals);
		setAlcohol(alcohol);
		this.userProfile = user;
    }

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public Points date(LocalDate date) {
        this.date = date;
        return this;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getExercise() {
        return exercise;
    }

    public Points exercise(Integer exercise) {
        setExercise(exercise);
        return this;
    }

    public void setExercise(Integer exercise) {
    	if(exercise != null)
    		this.exercise = exercise;
    }

    public Integer getMeals() {
        return meals;
    }

    public Points meals(Integer meals) {
        setMeals(meals);
        return this;
    }

    public void setMeals(Integer meals) {
    	if(meals != null)
    		this.meals = meals;
    }

    public Integer getAlcohol() {
        return alcohol;
    }

    public Points alcohol(Integer alcohol) {
        setAlcohol(alcohol);
        return this;
    }

    public void setAlcohol(Integer alcohol) {
    	if(alcohol != null)
    		this.alcohol = alcohol;
    }

    public String getNotes() {
        return notes;
    }

    public Points notes(String notes) {
        this.notes = notes;
        return this;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public User getUserProfile() {
        return userProfile;
    }

    public Points userProfile(User user) {
        this.userProfile = user;
        return this;
    }

    public void setUserProfile(User user) {
        this.userProfile = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Points points = (Points) o;
        if (points.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, points.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Points{" +
            "id=" + id +
            ", date='" + date + "'" +
            ", exercise='" + exercise + "'" +
            ", meals='" + meals + "'" +
            ", alcohol='" + alcohol + "'" +
            ", notes='" + notes + "'" +
            '}';
    }
}
