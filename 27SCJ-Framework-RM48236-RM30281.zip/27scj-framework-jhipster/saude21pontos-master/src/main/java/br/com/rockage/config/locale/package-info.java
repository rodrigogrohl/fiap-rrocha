/**
 * Locale specific code.
 */
package br.com.rockage.config.locale;
