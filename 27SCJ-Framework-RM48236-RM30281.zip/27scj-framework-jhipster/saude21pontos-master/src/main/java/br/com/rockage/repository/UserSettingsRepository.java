package br.com.rockage.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.rockage.domain.UserSettings;

/**
 * Spring Data JPA repository for the UserSettings entity.
 */
public interface UserSettingsRepository extends JpaRepository<UserSettings,Long> {
	
	Optional<UserSettings> findOneByUserLogin(String login);

}
