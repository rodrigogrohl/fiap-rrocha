package br.com.rockage.service.impl;

import br.com.rockage.service.UserSettingsService;
import br.com.rockage.domain.UserSettings;
import br.com.rockage.repository.UserSettingsRepository;
import br.com.rockage.repository.search.UserSettingsSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing UserSettings.
 */
@Service
@Transactional
public class UserSettingsServiceImpl implements UserSettingsService{

    private final Logger log = LoggerFactory.getLogger(UserSettingsServiceImpl.class);
    
    @Inject
    private UserSettingsRepository userSettingsRepository;

    @Inject
    private UserSettingsSearchRepository userSettingsSearchRepository;

    /**
     * Save a userSettings.
     *
     * @param userSettings the entity to save
     * @return the persisted entity
     */
    public UserSettings save(UserSettings userSettings) {
        log.debug("Request to save UserSettings : {}", userSettings);
        UserSettings result = userSettingsRepository.save(userSettings);
        userSettingsSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the userSettings.
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public Page<UserSettings> findAll(Pageable pageable) {
        log.debug("Request to get all UserSettings");
        Page<UserSettings> result = userSettingsRepository.findAll(pageable);
        return result;
    }

    /**
     *  Get one userSettings by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public UserSettings findOne(Long id) {
        log.debug("Request to get UserSettings : {}", id);
        UserSettings userSettings = userSettingsRepository.findOne(id);
        return userSettings;
    }

    /**
     *  Delete the  userSettings by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete UserSettings : {}", id);
        userSettingsRepository.delete(id);
        userSettingsSearchRepository.delete(id);
    }

    /**
     * Search for the userSettings corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public Page<UserSettings> search(String query, Pageable pageable) {
        log.debug("Request to search for a page of UserSettings for query {}", query);
        Page<UserSettings> result = userSettingsSearchRepository.search(queryStringQuery(query), pageable);
        return result;
    }

    /**
     * Find the UserSettings by the login
     * 
     * @author Rodrigo Rocha
     */
    @Transactional(readOnly = true)
	public Optional<UserSettings> findOneByUserLogin(String login) {
		log.debug("Request to search the UserSettings for user {}", login);
		return userSettingsRepository.findOneByUserLogin(login);
	}
}
