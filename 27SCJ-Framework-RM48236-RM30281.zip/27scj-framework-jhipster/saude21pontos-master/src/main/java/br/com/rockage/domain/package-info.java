/**
 * JPA domain objects.
 */
package br.com.rockage.domain;
