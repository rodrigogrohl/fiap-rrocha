package br.com.rockage.web.rest.vm;

import java.util.List;

import br.com.rockage.domain.BloodPressure;

/**
 * @author rodrigor
 *
 */
public class BloodPressureByPeriod {
	
	private String period;
	
	private List<BloodPressure> readings;

	public BloodPressureByPeriod(String period, List<BloodPressure> readings) {
		super();
		this.period = period;
		this.readings = readings;
	}
	
	public BloodPressureByPeriod() { }

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public List<BloodPressure> getReadings() {
		return readings;
	}

	public void setReadings(List<BloodPressure> readings) {
		this.readings = readings;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((period == null) ? 0 : period.hashCode());
		result = prime * result + ((readings == null) ? 0 : readings.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BloodPressureByPeriod other = (BloodPressureByPeriod) obj;
		if (period == null) {
			if (other.period != null)
				return false;
		} else if (!period.equals(other.period))
			return false;
		if (readings == null) {
			if (other.readings != null)
				return false;
		} else if (!readings.equals(other.readings))
			return false;
		return true;
	}
}
