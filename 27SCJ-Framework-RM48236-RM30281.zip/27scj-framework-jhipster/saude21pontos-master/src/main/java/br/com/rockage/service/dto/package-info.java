/**
 * Data Transfer Objects.
 */
package br.com.rockage.service.dto;
