/**
 * Service layer beans.
 */
package br.com.rockage.service;
