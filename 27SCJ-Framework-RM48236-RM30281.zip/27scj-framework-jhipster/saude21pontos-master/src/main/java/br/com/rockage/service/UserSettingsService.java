package br.com.rockage.service;

import br.com.rockage.domain.UserSettings;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing UserSettings.
 */
public interface UserSettingsService {

    /**
     * Save a userSettings.
     *
     * @param userSettings the entity to save
     * @return the persisted entity
     */
    UserSettings save(UserSettings userSettings);

    /**
     *  Get all the userSettings.
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    Page<UserSettings> findAll(Pageable pageable);

    /**
     *  Get the "id" userSettings.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    UserSettings findOne(Long id);

    /**
     *  Delete the "id" userSettings.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the userSettings corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @param pageable the pagination information
     *  @return the list of entities
     */
    Page<UserSettings> search(String query, Pageable pageable);
    
    /**
     * Get the UserSettings by the login parameter
     * 
     * @param login
     * @return UserSettings
     * @author Rodrigo Rocha
     */
    Optional<UserSettings> findOneByUserLogin(String login);
}
