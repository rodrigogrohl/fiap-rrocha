/**
 * WebSocket services, using Spring Websocket.
 */
package br.com.rockage.web.websocket;
