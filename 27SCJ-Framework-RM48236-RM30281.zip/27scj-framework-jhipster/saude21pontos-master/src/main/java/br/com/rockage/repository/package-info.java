/**
 * Spring Data JPA repositories.
 */
package br.com.rockage.repository;
