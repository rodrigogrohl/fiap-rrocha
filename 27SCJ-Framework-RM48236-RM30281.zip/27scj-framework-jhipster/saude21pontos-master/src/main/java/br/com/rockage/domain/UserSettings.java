package br.com.rockage.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

import br.com.rockage.domain.enumeration.Units;

/**
 * A UserSettings.
 */
@Entity
@Table(name = "user_settings")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "usersettings")
public class UserSettings implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Min(value = 10)
    @Max(value = 21)
    @Column(name = "weekly_goal", nullable = false)
    private Integer weeklyGoal;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "weight_units", nullable = false)
    private Units weightUnits;

    @Column(name = "measure_weight")
    private Boolean measureWeight;

    @Column(name = "measure_blood_pressure")
    private Boolean measureBloodPressure;

    @OneToOne
    @JoinColumn(unique = true)
    private UserProfile userProfile;

    @OneToOne
    @JoinColumn(unique = true)
    private User user;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getWeeklyGoal() {
        return weeklyGoal;
    }

    public UserSettings weeklyGoal(Integer weeklyGoal) {
        this.weeklyGoal = weeklyGoal;
        return this;
    }

    public void setWeeklyGoal(Integer weeklyGoal) {
        this.weeklyGoal = weeklyGoal;
    }

    public Units getWeightUnits() {
        return weightUnits;
    }

    public UserSettings weightUnits(Units weightUnits) {
        this.weightUnits = weightUnits;
        return this;
    }

    public void setWeightUnits(Units weightUnits) {
        this.weightUnits = weightUnits;
    }

    public Boolean isMeasureWeight() {
        return measureWeight;
    }

    public UserSettings measureWeight(Boolean measureWeight) {
        this.measureWeight = measureWeight;
        return this;
    }

    public void setMeasureWeight(Boolean measureWeight) {
        this.measureWeight = measureWeight;
    }

    public Boolean isMeasureBloodPressure() {
        return measureBloodPressure;
    }

    public UserSettings measureBloodPressure(Boolean measureBloodPressure) {
        this.measureBloodPressure = measureBloodPressure;
        return this;
    }

    public void setMeasureBloodPressure(Boolean measureBloodPressure) {
        this.measureBloodPressure = measureBloodPressure;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public UserSettings userProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
        return this;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

    public User getUser() {
        return user;
    }

    public UserSettings user(User user) {
        this.user = user;
        return this;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UserSettings userSettings = (UserSettings) o;
        if (userSettings.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, userSettings.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserSettings{" +
            "id=" + id +
            ", weeklyGoal='" + weeklyGoal + "'" +
            ", weightUnits='" + weightUnits + "'" +
            ", measureWeight='" + measureWeight + "'" +
            ", measureBloodPressure='" + measureBloodPressure + "'" +
            '}';
    }
}
