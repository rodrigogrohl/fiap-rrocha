/**
 * Data Access Objects used by WebSocket services.
 */
package br.com.rockage.web.websocket.dto;
