/**
 * View Models used by Spring MVC REST controllers.
 */
package br.com.rockage.web.rest.vm;
