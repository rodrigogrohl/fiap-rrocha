/**
 * Async helpers.
 */
package br.com.rockage.async;
