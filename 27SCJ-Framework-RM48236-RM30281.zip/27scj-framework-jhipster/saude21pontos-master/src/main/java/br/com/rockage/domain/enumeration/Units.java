package br.com.rockage.domain.enumeration;

/**
 * The Units enumeration.
 */
public enum Units {
    KG,POUNDS
}
